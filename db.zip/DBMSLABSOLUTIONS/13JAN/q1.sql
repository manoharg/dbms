CREATE TABLE employee(
     Emp_Id INT AUTO_INCREMENT NOT NULL,
     Name VARCHAR (20) NOT NULL,
     Designation VARCHAR (20) NOT NULL,
     Branch VARCHAR (20) NOT NULL,
     PRIMARY KEY (Emp_id));

ALTER TABLE employee ADD Salary FLOAT NOT NULL;

insert into employee (name,designation,branch,salary) values ("Shyam","Cashier","Allahabad","16000");
insert into employee (name,designation,branch,salary) values ("Anika","Manager","Kanpur","16000");
insert into employee (name,designation,branch,salary) values ("Govind","Assistant","Varansi","1600");
insert into employee (name,designation,branch,salary) values ("Harshit","CEO","Allahabad","1600000");
insert into employee (name,designation,branch,salary) values ("RadheShyam","CTO","Allahabad","1600000");
insert into employee (name,designation,branch,salary) values ("Robin","Summer Analyst","Allahabad","1600");


delete from employee where Emp_Id = 4;

DROP TABLE employee;
