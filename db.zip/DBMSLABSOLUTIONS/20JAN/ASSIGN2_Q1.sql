CREATE TABLE DEPARTMENT(
dep_id INT(10) not null,
dep_name varchar(15) not null,
employee varchar(20) not null,
emp_id int(10) not null,
locationid int(10) not null,
salary int(10) not null,
primary key (dep_id));

INSERT INTO DEPARTMENT (dep_id,dep_name,employee,emp_id,locationid,salary) VALUES (10,"administration","shyam",200,1700,10000),(20,"marketing","anika",201,1800,20000),
(50,"shipping","govind",124,1500,30000),
(60,"it","anika",103,1400,20000),
(80,"sales","ram",149,2500,40000),
(90,"executing","abdul",100,1700,10000),
(110,"accounting","venktesh",205,1700,30000),
(190,"contracting","anupma",333,1700,20000);

UPDATE DEPARTMENT SET salary = 33000 WHERE locationid = 1700;

SELECT MIN(salary) FROM DEPARTMENT;

SELECT AVG(salary) FROM DEPARTMENT;

SELECT emp_id,salary FROM DEPARTMENT WHERE salary > (SELECT MIN(salary) FROM DEPARTMENT);

SELECT d1.employee FROM DEPARTMENT d1, DEPARTMENT d2 WHERE d2.employee="abdul" AND d1.locationid=d2.locationid;

SELECT NOW() AS Date;

SELECT MAX(salary) as Highest, MIN(salary) as Lowest, SUM(salary) as Sum, AVG(salary) as Average FROM DEPARTMENT;

SELECT locationid as Location, COUNT(*) as Count FROM DEPARTMENT GROUP BY locationid;

SELECT (MAX(salary) - MIN(salary)) AS DIFFERENCE FROM DEPARTMENT;

SELECT emp_id,employee,salary,(salary*115/100) as NewSalary FROM DEPARTMENT;
