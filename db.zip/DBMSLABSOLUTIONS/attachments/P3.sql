DECLARE
  i   INT ;
  ans INT;
  n   INT ;
PROCEDURE FACT  (n IN INT)
IS
BEGIN
ans:=1;
 FOR k IN 1..n  LOOP
  ans:=ans*k;
  END LOOP;
  
end;


BEGIN
ans:=1;
  n     :=&enter_value;
fact(n);
 dbms_output.put_line('factorial is' ||ans);
 
END;

