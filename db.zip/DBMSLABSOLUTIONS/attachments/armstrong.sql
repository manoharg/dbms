DECLARE
  var1 INT ;
  b  INT ;
  var2 INT ;
  d  INT;
  c  INT;
BEGIN
  c       :=0;
  d       :=&enter_the_armstrong_no;
  var1      :=d;
  var2      :=10;
  WHILE (var1>0)
  LOOP
    b :=var1 mod 10;
    c :=c +power(b,3);
    var1:=trunc(var1/var2) ;
  END LOOP;
  IF (c=d) THEN
    dbms_output.put_line('Yes'||c);
  ELSE
    dbms_output.put_line('no '||c);
  END IF;
END;