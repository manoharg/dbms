DECLARE
  var1 INT ;
  b  INT ;
  var2 INT ;
  d  INT;
  c  INT;
  n int ;
  procedure armstrong(n in int)
  is
  begin
   c       :=0;
  WHILE (var1>0)
  LOOP
    b :=var1 mod 10;
    c :=c +power(b,3);
    var1:=trunc(var1/10) ;
  END LOOP;
  end;
BEGIN
 
  d       :=&enter_the_armstrong_no;
  var1      :=d;

  armstrong(var1);
  IF (c=d) THEN
    dbms_output.put_line('Yes'||c);
  ELSE
    dbms_output.put_line('no '||c);
  END IF;
END;