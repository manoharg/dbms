CREATE TABLE customer(Cust_Id INT NOT NULL auto_increment,Cust_Name VARCHAR (20) NOT NULL,
AccNo VARCHAR (20) NOT NULL,
Balance INT (20) NOT NULL,
Branch VARCHAR (20) NOT NULL,
PRIMARY KEY (Cust_id));


insert into customer (Cust_Name,AccNo,Balance,Branch) values ("Shyam","1000121","25000","Allahabad");
insert into customer (Cust_Name,AccNo,Balance,Branch) values ("Anika","1000125","27111","Kanpur");
insert into customer (Cust_Name,AccNo,Balance,Branch) values ("Govind","100131","100376","Varanasi");
insert into customer (Cust_Name,AccNo,Balance,Branch) values ("Harshit","1000135","10000","Vadodara");
insert into customer (Cust_Name,AccNo,Balance,Branch) values ("RadheShyam","1000136","10000","Mumbai");
insert into customer (Cust_Name,AccNo,Balance,Branch) values ("Robin","1000137","10000","Allahabad");

select * from customer;

alter table customer add DOJ Date NOT NULL;

select * from customer where Balance=10000;

update customer set Branch = "Mathura" where Cust_Id = 1;

alter table customer add PinCode INT NOT NULL;


update customer set PinCode = "230154" where Branch="Mathura";
update customer set PinCode = "230157" where Branch="Kanpur";
update customer set PinCode = "230152" where Branch="Vadodara";
update customer set PinCode = "230156" where Branch="Varanasi";
update customer set PinCode = "230159" where Branch="Mumbai";
update customer set PinCode = "211004" where Branch="Allahabad";

select Cust_Name,AccNo,Branch from customer where Balance > 25000;

select Cust_Name,AccNo,Branch from customer where Balance > 25000 and Branch="Varanasi";

