LOAD DATA LOCAL INFILE '/home/user/Desktop/data.txt' into table db20144144.temp_cust
