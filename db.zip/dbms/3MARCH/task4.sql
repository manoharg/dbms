Ques 1)
 a) SELECT A FROM R;
 b) SELECT * FROM R WHERE B = 17;
 c) SELECT * FROM R,S; 
 d) SELECT r.A,s.F FROM R r,S s WHERE r.C = s.D;
 
Ques 2)
 a) SELECT * FROM  r1
    UNION 
    SELECT * FROM  r2;
  
 b) SELECT * FROM r1
    INTERSECT
    SELECT * FROM r2;
  
 c) SELECT * FROM r1
    EXCEPT
    SELECT * FROM r2;
   
 d) SELECT r1.A,r1.B,r2.C from r1 ,r2 where r1.B = r2.B;
    
Ques 3)
 a) CREATE TABLE employee(
    employee_name VARCHAR(30) NOT NULL,
    street VARCHAR(30) NOT NULL,
    city VARCHAR(50) NOT NULL,
    PRIMARY KEY (employee_name)
    );
    
    CREATE TABLE works(
    employee_name VARCHAR(30) NOT NULL,
    company_name VARCHAR(30) NOT NULL,
    salary INT NOT NULL,
    PRIMARY KEY (employee_name,company_name),
    FOREIGN KEY (employee_name) REFERENCES employee,
    FOREIGN KEY (company_name) REFERENCES company
    );
    
    CREATE TABLE company(
    company_name VARCHAR(30) NOT NULL,
    city VARCHAR(30) NOT NULL,
    PRIMARY KEY (company_name)
    );
    
    CREATE TABLE manages(
    employee_name VARCHAR(30),
    manager_name VARCHAR(30),
    PRIMARY KEY (employee_name,manager_name),
    FOREIGN KEY (employee_name) REFERENCES employee,
    FOREIGN KEY (manager_name) REFERENCES employee
    );
    
 b)
 
 check condition for the works table:-
check((employee-name, company-name) in
(select e.employee-name, c.company-name
from employee e, company c
where e.city = c.city
)
)
b. check condition for the works table:-
Exercises 55
check(
salary < all
(select manager-salary
from (select manager-name, manages.employee-name as emp-name,
salary as manager-salary
from works, manages
where works.employee-name = manages.manager-name)
where employee-name = emp-name
)
)
 
 
     1) CHECK ((SELECT city FROM employee e where e.employee_name=employee_name)==(SELECT  city FROM company c where c.company_name=company_name));
 
     2) CHECK ((SELECT salary FROM works w where w.employee_name=employee_name)<=(SELECT salary FROM works m where m.employee_name=manager_name)); 
 
 
 Ques 4)  
       CREATE TABLE suppliers (
       sid INT NOT NULL,
       sname VARCHAR(30) NOT NULL,
       city VARCHAR(30) NOT NULL,
       PRIMARY KEY (sid)
       );
       
       CREATE TABLE parts(
       pid INT NOT NULL,
       pname VARCHAR(30) NOT NULL,
       color VARCHAR(30) NOT NULL,
       PRIMARY KEY (pid)
       );
       
       CREATE TABLE orders(
       sid INT NOT NULL,
       pid INT NOT NULL,
       quantity INT NOT NULL,
       PRIMARY KEY (sid,pid),
       FOREIGN KEY (sid) REFERENCES suppliers,
       FOREIGN KEY (pid) REFERENCES parts
       );
 1.) SELECT P.pname FROM Parts P,Suppliers S,Orders O where O.pid = P.pid and O.sid = S.sid and S.city IN ("Mumbai","Delhi","Kanpur");
 
 2.) SELECT S.sid,S.sname,S.city from Suppliers S,Parts P,Orders O where O.sid=S.sid and O.pid=P.pid and (P.color="yellow" OR P.color="purple") and O.quantity>100;
 
 3.) SELECT P1.pid from Parts P1,Suppliers S1,Orders O1,Parts P2,Suppliers S2,Orders O2 WHERE P1.pid = P2.pid and P1.pid = O1.pid and S1.sid = O1.sid and P2.pid = O2.pid and S2.sid = O2.sid and S1.sid!=S2.sid and S1.name = "Delhite" and (O1.quantity > O2.quantity and O1.quantity-O2.quantity>=100);
  
 4.) SELECT Distinct S.sid,S.sname,S.city FROM Suppliers S,Orders O,Parts P where O.sid = S.sid and O.pid = P.pid and P.color="green";
 
 5.) SELECT P.pname,O.quantity FROM Parts P,Orders O where O.pid = P.pid and P.color = "red";
 
 6.) SELECT P.pid,P.pname FROM Parts P, Orders O, Suppliers S where O.pid=P.pid and O.sid=S.sid and S.city = "Bikaner" ORDER BY P.pname
     INTERSECT 
     SELECT P1.pid,P1.pname FROM Parts P1, Orders O1, Suppliers S1 where O1.pid=P1.pid and O1.sid=S1.sid and S1.city = "Mumbai" ORDER BY P1.pname;
 
 7.) SELECT P.pid,P.pname FROM Parts P, Orders O, Suppliers S where O.pid=P.pid and O.sid=S.sid and S.city = "Bikaner" ORDER BY P.pname
     EXCEPT 
     SELECT P1.pid,P1.pname FROM Parts P1, Orders O1, Suppliers S1 where O1.pid=P1.pid and O1.sid=S1.sid and S1.city = "Mumbai" ORDER BY P1.pname;
  
 8.) SELECT sid,MAX(O.quantity),O.quantity FROM Orders O GROUPY BY (sid) HAVING (SELECT MIN(O.quantity))>100;
