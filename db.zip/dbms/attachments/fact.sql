DECLARE
  i   INT ;
  ans INT;
  n   INT ;
BEGIN
ans:=1;
  n     :=&enter_value;
  FOR k IN 1..n  LOOP
    ans:=ans*k;
  END LOOP;
  dbms_output.put_line('factorial is' ||ans);
END;