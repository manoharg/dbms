
DECLARE
 a INT ;
   b INT ;
   c int ;     
BEGIN
    a := &enter_valuea;
    b := &enter_valueb;
    c := &enter_valuec;
if (a>b) and (a>c)
    then
    dbms_output.put_line('a is greatest '||a);
elsif (b>a) and (b>c)
    then
    dbms_output.put_line('b is greatest '||b);
else
    dbms_output.put_line('c is  greatest '||c);
end if;
  
END;