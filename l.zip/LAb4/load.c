
/*

Name : Buvaneish Sundar
Reg No : 20148036
CS-A
Program : C program for process migration (load file).
Date :7-10-17

*/


#include<stdio.h>
int main()
{
	while(1);
	return 0;
}
