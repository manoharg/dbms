
/*

Name : Buvaneish Sundar
Reg No : 20148036
CS-A
Program : C program for process migration.
Date :7-10-17

*/


#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<sys/stat.h>
#include<errno.h>
#include<string.h>

int min(double a, double b, double c)
{
	if(a <= b && a <= c)
		return 1;
	if(b <= c && b <= a)
		return 2;
	return 3;
}

double getLoad(int node)
{
	char arr1[100] = "mosctl status ";
	char arr2[100];
	char arr3[100] = " | awk 'FNR == 2 {print $2}'> me1.txt";
				//char* command="mosctl status 1 | awk 'FNR == 2 {print $2}'> CPU1.txt"; 
	sprintf(arr2, "%d", node);
	strcat(arr1, arr2);
	strcat(arr1, arr3);

	system(arr1);

	double var;
	
	FILE *fp = fopen("me1.txt", "r");

	fscanf(fp, "%lf", &var);

	return var;
}

int main()
{
        printf("Author :Aquil Raza\nCS-A\nReg No : 20143098\nDate : 07-10-17\n");
	double i, j, k, n;
	int f;
	for(f=0; f<10000;f++);

	i = getLoad(1);
	
	printf("Load of node 1 is %lf\n", i);

	j = getLoad(2);
	
	printf("Load of node 2 is %lf\n", j);

	k = getLoad(3);
	
	printf("Load of node 3 is %lf\n", k);

	f = min(i, j, k);

	open("/proc/self/migrate", 1, f);

	printf("process migrates to %d node\n", f);

	sleep(1000);

	return 0;
}
	
