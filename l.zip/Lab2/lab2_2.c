/*
Name : Golla Manohar
Regd No: 2014419
Branch :CSE-A
Date : 28-08-2017
*/
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<string.h>
#include<unistd.h>
pthread_mutex_t lock1, lock2;
void *w1(void *arg)
{	
printf("Thread 1 requesting lock 1\n");
pthread_mutex_lock(&lock1);
printf("Thread 1 received lock 1\n");
//printf("Thread  1 \n");
char buffer[100]="writing1\n";

FILE *fp=fopen("file1.txt","w");
 fwrite(buffer, strlen(buffer)+1, 1, fp);
 printf("Thread 1 requesting lock 2\n");
 	pthread_mutex_lock(&lock2);
 	 printf("Thread 1 received lock 2\n");
FILE *fp2=fopen("file2.txt","w");
if(fp2==NULL)
{
	printf("deadlock");
}
 fclose(fp);
 fclose(fp2);
  pthread_mutex_unlock(&lock1);
    pthread_mutex_unlock(&lock2);
}

void *w2(void *arg)
{
printf("Thread 2 requesting lock 2\n");
pthread_mutex_lock(&lock2);
 printf("Thread 2 received lock 2\n");
char buffer[100]="writing2\n";

FILE *fp=fopen("file2.txt","w");

 fwrite(buffer, strlen(buffer)+1, 1, fp);
 
printf("Thread 2 requesting lock 1\n");
pthread_mutex_lock(&lock1);
 printf("Thread 2 received lock 1\n");
FILE *fp2=fopen("file1.txt","w");
if(fp2==NULL)
{
	printf("deadlock");
}
 fclose(fp);
 fclose(fp2);
  pthread_mutex_unlock(&lock2);
   pthread_mutex_unlock(&lock1);
}
int main()
{

pthread_t one, two;
if (pthread_mutex_init(&lock1, NULL) != 0)
    {
        printf("\n mutex init failed\n");
        return 1;
    }
    if (pthread_mutex_init(&lock2, NULL) != 0)
    {
        printf("\n mutex init failed\n");
        return 1;
    }
pthread_create(&one, NULL, w1, NULL);
pthread_create(&two, NULL, w2, NULL);
pthread_join(one,NULL);
pthread_join(two,NULL);
pthread_mutex_destroy(&lock1);
pthread_mutex_destroy(&lock2);
return 0;
}

