/*
Name : Golla Manohar
Regd No: 2014419
Branch :CSE-A
Date : 28-08-2017
*/
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<string.h>
#include<unistd.h>
pthread_mutex_t lock1, lock2;
void *w1(void *arg)
{	

printf("Thread 1 requesting lock 1\n");

if(pthread_mutex_trylock(&lock1)==0)
{
printf("Thread 1 received lock 1\n");
char buffer[100]="writing to file1 by thread1\n";
sleep(2);
FILE *fp=fopen("file1.txt","w");
 fwrite(buffer, strlen(buffer)+1, 1, fp);
 fclose(fp);
 pthread_mutex_unlock(&lock1);
}
else
{
printf("lock 1 is already acquired by another thread \n");
  pthread_mutex_unlock(&lock1);
}
//printf("Thread  1 \n");
 
printf("Thread 1 requesting lock 2\n");
if(pthread_mutex_trylock(&lock2)==0)
{printf("Thread 1 received lock 2\n");
sleep(2);
FILE *fp2=fopen("file2.txt","w");
char b[100]="writing to file 2 by thread 1\n";
 fwrite(b, strlen(b)+1, 1, fp2);
     pthread_mutex_unlock(&lock2);
      fclose(fp2);
}
else{
printf("lock 2 is already acquired by another thread \n");
  pthread_mutex_unlock(&lock2);
 }

 
}

void *w2(void *arg)
{

 
printf("Thread 2 requesting lock 2\n");

if(pthread_mutex_trylock(&lock2)==0)
{
printf("Thread 2 received lock 2\n");
char buffer[100]="writing2\n";
sleep(2);
FILE *fp=fopen("file2.txt","w");

 fwrite(buffer, strlen(buffer)+1, 1, fp);
 fclose(fp);
pthread_mutex_unlock(&lock2);
 }
else{
printf("lock 2 is already acquired by another thread \n");
   pthread_mutex_unlock(&lock2);
   }

 printf("Thread 2 requesting lock 1\n");
 
if( pthread_mutex_trylock(&lock1)==0)
{
printf("Thread 2 received lock 1\n");
FILE *fp2=fopen("file1.txt","w");
char b[100]="writing to file 1 by thread 2\n";
 fwrite(b, strlen(b)+1, 1, fp2);
 sleep(2);
     //pthread_mutex_unlock(&lock2);
      fclose(fp2);
         pthread_mutex_unlock(&lock1);
}
else{
printf("lock 1 is already acquired by another thread \n");
  pthread_mutex_unlock(&lock1);
  }

}
int main()
{

pthread_t one, two;
if (pthread_mutex_init(&lock1, NULL) != 0)
    {
        printf("\n mutex init failed\n");
        return 1;
    }
    if (pthread_mutex_init(&lock2, NULL) != 0)
    {
        printf("\n mutex init failed\n");
        return 1;
    }
pthread_create(&one, NULL, w1, NULL);
pthread_create(&two, NULL, w2, NULL);
pthread_join(one,NULL);
pthread_join(two,NULL);
pthread_mutex_destroy(&lock1);
pthread_mutex_destroy(&lock2);
return 0;
}

