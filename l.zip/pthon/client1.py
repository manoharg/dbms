
#client program for table upadtion

import socket
import pickle

print('Apoor Jayanth\n20144146\nCS1\n16-10-17')

label = ['Node', 'IP Address', 'Port']

table = [[1, '172.31.100.36', 2345]]

available_dict = {1 : 1}

for item in label:
	print (item, end = " ")

print()

for entry in table:
	for value in entry:
		print(value, end = " ")
	print()

s = socket.socket()
s.connect(('127.0.0.1', 6007))

print('sending table to server')

sent_data = pickle.dumps(table)

s.send(sent_data)

print('receiving table from server')

received_data = pickle.loads(s.recv(1024))

for entry in received_data:
	if entry[0] not in available_dict:
		available_dict[entry[0]] = 1
		table.append(entry)
	
	else:
		for i in range(len(table)):
			if entry[0] == table[i][0]:
				table[i][1] = entry[1]
				table[i][2] = entry[2]
				break

table.sort()

print('Updated table is')

for item in label:
	print (item, end = " ")

print()

for entry in table:
	for value in entry:
		print(value, end = " ")
	print()

s.close()
