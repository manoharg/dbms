
#server program for table upation

import socket
import pickle

print('Apoor Jayanth\n20144146\nCS1\n16-10-17')

label = ['Node', 'IP Address', 'Port']

table = [[2, '172.31.100.40', 3128], [3, '172.31.100.52', 2323]]

available_dict = {2 : 1, 3 : 1}

print('Initial server table')

for item in label:
	print (item, end = " ")

print()

for entry in table:
	for value in entry:
		print(value, end = " ")
	print()

ss = socket.socket()
ss.bind(('', 6007))
ss.listen(5)

while True:
	s, addr = ss.accept()

	print('Table received from client')
	
	received_data = pickle.loads(s.recv(1024))

	for entry in received_data:
		if entry[0] not in available_dict:
			available_dict[entry[0]] = 1
			table.append(entry)
		else:
			for i in range(len(table)):
				if entry[0] == table[i][0]:
					table[i][1] = entry[1]
					table[i][2] = entry[2]
					break

	table.sort()

	print('Updated table is')

	for item in label:
		print (item, end = " ")

	print()

	for entry in table:
		for value in entry:
			print(value, end = " ")
		print()

	print('Sending updated table to client')

	sent_data = pickle.dumps(table)

	s.send(sent_data)

	s.close()


