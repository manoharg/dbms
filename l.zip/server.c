#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<sys/types.h>
#include<string.h>

int main()
{
int i;
struct sockaddr_in  se,cl;
//struct sockaddr_in cl,se;
int s=socket(PF_INET,SOCK_STREAM,0);
se.sin_family=AF_INET;
se.sin_port=htons(8080);
se.sin_addr.s_addr=inet_addr("127.0.0.1");
bind(s,(struct sockaddr *)&se,sizeof(se));
listen(s,4);

socklen_t l=sizeof(cl);
int c=accept(s,(struct sockaddr *)&cl,&l);
  printf("Received packet from %s:%d\n", inet_ntoa(cl.sin_addr), ntohs(cl.sin_port));
  FILE *fp=fopen("ser.txt","a");
  char *ip=inet_ntoa(cl.sin_addr);
  char *port;
  sprintf(port,"%d\n",ntohs(cl.sin_port));
  fputs(ip,fp);
  fputs("\t",fp);
  fputs(port,fp);
  
  fclose(fp);
char buf[1024];

recv(c,buf,1024,0);
FILE *fp2=fopen("ser.txt","r");
while(fgets(buf,1024,fp2)!=NULL)
{
write(c,buf,sizeof(buf));
fflush(stdout);
}


close(c);
close(s);
	
}
