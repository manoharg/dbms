#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<unistd.h>
#include<string.h>
#include<arpa/inet.h>
int main()
{
	int s=socket(PF_INET,SOCK_DGRAM,0);
	struct sockaddr_in se,cl;
	char buf[100];
	se.sin_family=AF_INET;
	se.sin_port=htons(8888);
	se.sin_addr.s_addr=inet_addr("127.0.0.1");
	while(1){
	printf("Enter msg:\n");
	scanf("%s",buf);
	sendto(s,buf,strlen(buf)+1,0,(struct sockaddr *)&se,sizeof(se));
	recvfrom(s,buf,100,0,NULL,NULL);
	printf("%s",buf);
	}
	close(s);
	
}
