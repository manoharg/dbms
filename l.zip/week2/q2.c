

/*

Author : Buvaneish Sundar
Reg no : 20148036
Date : 28-8-17

Write a program to implement a deadlock scenario, in which two threads are accessing two
resources concurrently.

*/


#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<pthread.h>

pthread_t tid[2];
pthread_mutex_t lock1, lock2;
void *func1(void *arg)
{

	pthread_mutex_lock(&lock1);
	printf("thread1 controlling resource 1\n");
        sleep(2);
	printf("thread1 requesting resource 2\n");
	pthread_mutex_lock(&lock2);
	printf("thread1 holding both the resources\n");
	pthread_mutex_unlock(&lock2);
	pthread_mutex_unlock(&lock1);
	return NULL;
}

void *func2(void *arg)
{
	pthread_mutex_lock(&lock2);
	printf("thread2 controlling resource 2\n");
        sleep(2);
	printf("thread2 requesting resource 1\n");
	pthread_mutex_lock(&lock1);
	printf("thread2 holding both the resources\n");
	pthread_mutex_unlock(&lock1);
	pthread_mutex_unlock(&lock2);
	return NULL;
}

int main()
{

	int i, j, k, n, option, t_no = 0;
	
	printf("Author : Aquil Raza\nCS-A\nReg No : 20143098\nDate : 28-8-17\n");
	
	if (pthread_mutex_init(&lock1, NULL) != 0)
    {
        printf("\n mutex init has failed\n");
        return 1;
	}
	
	if (pthread_mutex_init(&lock2, NULL) != 0)
    {
        printf("\n mutex init has failed\n");
        return 1;
	}
	
	pthread_create(&(tid[0]), NULL, &func1, NULL);
	pthread_create(&(tid[1]), NULL, &func2, NULL);
	
	pthread_join(tid[0], NULL);
	pthread_join(tid[1], NULL);
	
	pthread_mutex_destroy(&lock1);
	pthread_mutex_destroy(&lock2);
	return 0;	
}
		
		
		
		 
