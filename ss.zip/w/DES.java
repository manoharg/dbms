import javax.crypto.*;
import java.util.*;
public class DES
{
Cipher e,d;
DES(SecretKey key) throws Exception
{
e=Cipher.getInstance("DES");
d=Cipher.getInstance("DES");
e.init(Cipher.ENCRYPT_MODE,key);
d.init(Cipher.DECRYPT_MODE,key);

}
public String encrypt(String str)throws Exception
{

byte[] utf= str.getBytes("UTF8");
byte[] ef= e.doFinal(utf);
return new sun.misc.BASE64Encoder().encode(ef);
}
public String decrypt(String str) throws Exception
{

byte[] utf= new sun.misc.BASE64Decoder().decodeBuffer(str);
byte[] s= d.doFinal(utf);
String decode= new String(s,"UTF8");
return decode;

}
public static void main(String args[]) throws Exception 
{
SecretKey key = KeyGenerator.getInstance("DES").generateKey();
    DES encrypter = new DES(key);
    
    Scanner sc=new Scanner(System.in);
    String s=sc.next();
    String encrypted = encrypter.encrypt(s);
    System.out.println(encrypted);
    String decrypted = encrypter.decrypt(encrypted);
      System.out.println(decrypted);

}


}
