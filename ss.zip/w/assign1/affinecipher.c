//Affine Cipher
#include<stdio.h>
#include<string.h>
int main()
{
	char pt[100],ct[100],dt[100];
	int i,j=0,k,m;
	printf("Enter the plain text: ");
	scanf("%[^\n]s",pt);
	int l=strlen(pt);
	int mul,add,inverse;
	printf("Enter mul and add:");
	scanf("%d%d",&mul,&add);
//Encryption
	for(i=0;i<l;i++)
	{
	if(pt[i]==' ')
	continue;
	else {
	m=pt[i]-97;
	ct[j++]=(((m*mul)+add)%26)+97;

	}
	}
ct[j]='\0';
printf("\nEncrypted text:%s\n",ct);
l=strlen(ct);
j=0;
inverse=1;
while(1){

if((mul*inverse)%26==1)
break;
inverse++;
}
//Decryption
for(i=0;i<l;i++)
{
m=ct[i]-97;
dt[j++]=(((m%26-add%26+26)%26*inverse)%26)+97;
}
dt[j]='\0';
printf("\nPlain text after decryption is: %s\n\n",dt);


return 0;
}
