//Shift Cipher
#include<stdio.h>
#include<string.h>
int main()
{
	char pt[100],ct[100],dt[100];
	int i,j=0,k,m;
	printf("Enter the plain text: ");
	scanf("%[^\n]s",pt);
	int l=strlen(pt);
	printf("Enter k: ");
	scanf("%d",&k);
	//Encryption
	for(i=0;i<l;i++)
	{
		if(pt[i]==' ')
			continue;
		else{
		ct[j++]=(pt[i]-97+k)%26;
		ct[j-1]=ct[j-1]+97;

		}
	}
	ct[j]='\0';
	printf("\nEncrypted text: %s\n",ct);
	l=strlen(ct);
	j=0;
	for(i=0;i<l;i++)
	{
	if((m=ct[i]-k)<97)
 {
	dt[j++]=ct[i]-k+26;
  }
	else dt[j++]=ct[i]-k;

	}
	dt[j]='\0';
	printf("\nDecrypted text: %s\n\n",dt);
	return 0;
}
