//Substitution Cipher
#include<stdio.h>
#include<string.h>
int main()
{
	char pt[100],ct[100],dt[100];
	int i,j=0,k,m;
	printf("Enter the plain text: ");
	scanf("%[^\n]s",pt);
	int l=strlen(pt);
	char key[26]={'l','m','y','z','a','b','j','k','c','d','t','u','r','s','e','f','h','i','v','w','x','g','n','o','p','q'};

//Encryption

for(i=0;i<l;i++)
	{
	if(pt[i]==' ')
		//ct[j++]=' ';
		continue;
 else{
	m=pt[i]-97;
	ct[j++]=key[m];
 }
	}
ct[j]='\0';
printf("\nCipher text is: %s\n",ct);
l=strlen(ct);
//Decryption
	j=0;
	for(i=0;i<l;i++)
	{

			for(k=0;k<26;k++)
   {
   if(ct[i]==key[k])
		dt[j++]=k+97;

   }


	}
	dt[j]='\0';
		printf("\nPlain text after decryption:%s\n\n",dt);
	return 0;
}
