//Autokey Cipher
#include<stdio.h>
#include<string.h>

int main()
{
	char pt[100],ct[100],dt[100];
	int ks[100];
	int k,i,j,l,m,n=0;
	printf("Enter the plaintext\n");
	scanf("%[^\n]s",pt);
	//printf("%s\n",pt);
	printf("Enter the key: ");
	scanf("%d",&k);
	//encryption
	l=strlen(pt);
	ks[0]=k%26;
	j=1;
	for(i=1;i<l;i++)
	{
	if(pt[i-1]!=' ')
		ks[j++]=pt[i-1]-97;
	}
	/*for(i=0;i<j;i++)
	printf("%d ",ks[i]);
	printf("\n");*/
	j=0;
	for(i=0;i<l;i++)
	{
	if(pt[i]!=' '){
		m=(pt[i]-97+ks[j++])%26;
		//printf("%d ",m);
	ct[n++]=m+97;
	}
	}
	ct[n]='\0';
	printf("\nCiphertext is: %s\n",ct);
	//decryption
	l=strlen(ct);
	j=0;
	for(i=0;i<l;i++)
	{
		if((m=ct[i]-ks[i])<97)
 {
	dt[j++]=ct[i]-ks[i]+26;
  }
	else dt[j++]=ct[i]-ks[i];
	}
	dt[j]='\0';
	printf("\nPlaintext after decryption: \n%s\n\n",dt);
	return 0;
}
