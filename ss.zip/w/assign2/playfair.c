//Playfair Cipher
#include<stdio.h>
#include<string.h>

char mt[5][5]={{'l','g','p','b','a'},{'q','m','h','e','c'},{'u','r','n','i','f'},{'x','v','s','o','k'},{'z','y','w','t','p'}};
int row,col;
void check(char a)
{
int i,j;
for(i=0;i<5;i++)
{
for(j=0;j<5;j++)
{
if(mt[i][j]==a)
{row=i;
col=j;
break;
}
}
}

}

int main()
{
	char pt[100],npt[100],opt[2015],ct[205],dt[205],jp,js;
	printf("Enter the plaintext: ");
	scanf("%[^\n]s",pt);
	int i,j,k,l;
	l=strlen(pt);
	j=0;
	//Adding filler letters
	for(i=0;i<l;i++)
	{
		if(pt[i]!=' ')
		npt[j++]=pt[i];

	}
	npt[j]='\0';
	l=strlen(npt);
	for(i=0;i<l;i++)
	pt[i]=npt[i];
	pt[i]='\0';
	for(i=0;i<l;i++)
	{
		if(npt[i]=='j')
		{
		npt[i]='i';
		}
	}
	j=0;

	for(i=0;npt[i]!='\0';)
	{
		if(npt[i]==npt[i+1])
		{
			opt[j++]=npt[i];
			opt[j++]='x';
			i++;
		}
		else {
		opt[j++]=npt[i];
		opt[j++]=npt[i+1];
		i=i+2;

		}
	}
	opt[j]='\0';
	l=strlen(opt);

	if(l%2!=0)
	{
	opt[l]='x';
	opt[l+1]='\0';
	}

	int r1,r2,c1,c2;
	j=0;
	//Encryption
	for(i=0;opt[i]!='\0';)
	{
		check(opt[i]);
		r1=row;
		c1=col;
		check(opt[i+1]);
		r2=row;
		c2=col;
		if(r1==r2)
		{
		ct[j++]=mt[r1][(c1+1)%5];
		ct[j++]=mt[r2][(c2+1)%5];
		}
		else if(c1==c2)
		{
		ct[j++]=mt[(r1+1)%5][c1];
		ct[j++]=mt[(r2+1)%5][c2];
		}
		else
		{
		ct[j++]=mt[r1][c2];
		ct[j++]=mt[r2][c1];
		}
	i=i+2;
	}
	ct[j]='\0';
	printf("\nCiphertext is: %s\n",ct);
	//Decryption

	l=strlen(ct);

	j=0;
	for(i=0;i<l-1;)
	{
		check(ct[i]);
		r1=row;
		c1=col;
		check(ct[i+1]);
		r2=row;
		c2=col;
		if(r1==r2)
		{
		dt[j++]=mt[r1][(c1-1)%5];
		dt[j++]=mt[r2][(c2-1)%5];
		}
		else if(c1==c2)
		{
		dt[j++]=mt[(r1-1)%5][c1];
		dt[j++]=mt[(r2-1)%5][c2];
		}
		else
		{
		dt[j++]=mt[r1][c2];
		dt[j++]=mt[r2][c1];
		}
	i=i+2;
	}
	dt[j]='\0';
	printf("\nPlaintext after decryption:\n");
	printf("%s\n\n",pt);

	return 0;

}
