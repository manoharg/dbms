//Hill Cipher
#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
#define MOD 26
int adj[3][3];
int co[3][3];
int k[3][3];
int finddet()
{
	int d=k[0][0]*((k[1][1]*k[2][2])%26-(k[1][2]*k[2][1])%26+26)%26-k[0][1]*((k[1][0]*k[2][2])%26-(k[1][2]*k[2][0])%26+26)%26+k[0][2]*((k[1][0]*k[2][1])%26-(k[1][1]*k[2][0])%26+26)%26;
	return (d%26 +26)%26;
}
void transpose()
{
	int a,b;
	for(a=0;a<3;a++)
		for(b=0;b<3;b++)
			adj[a][b]=co[b][a];
}
int twodet(int mat[2][2])
{
	int d=((mat[0][0]*mat[1][1])%26-(mat[0][1]*mat[1][0])%26+26)%26;
	return d;
}
void findadj()
{
	int a,b,c,d;
	for(a=0;a<3;a++)
	{
		for(b=0;b<3;b++)
		{
			int x=pow(-1,a+b);
			int temp[2][2];
			int i=0,j=0;
			for(c=0;c<3;c++)
			{
				for(d=0;d<3;d++)
				{
					if(c!=a&&d!=b)
					{
						if(i<2&&j<2)
						{
							temp[i][j++]=k[c][d];
						}
						else if(i<2)
						{
							i++;
							j=0;
							temp[i][j++]=k[c][d];
						}
					}
				}
			}
			int y=twodet(temp);
			co[a][b]=((x+26)%26*y%26)%26;
		}
	}
	transpose();
}
int modInverse(int n){
	int i = 0;
	for(i=0;i<MOD;i++){
		if((i*n)%MOD == 1)
			return i;
	}
}
int main()
{
	char s[100];
	int i,j;
	printf("Enter plaintext\n");
	scanf("%[^\n]s",s);
	printf("Enter key matrix\n");
	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
			scanf("%d",&k[i][j]);
	int p[3][1];
	int ans[3][1];
	i=0;
	char en[100];
	int a,b,c;
	int f=0;
	int l=strlen(s);
	//Encryption
	while(i<l)
	{
		for(j=0;j<3;j++)
		{
			if(i<l)
				p[j][0]=s[i++]-97;
			else
				p[j][0]=25;
		}
		for(a=0;a<3;a++)
		{
			for(b=0;b<1;b++)
			{
				ans[a][b]=0;
				for(c=0;c<3;c++)
					ans[a][b]=((ans[a][b])%26+(k[a][c]%26*p[c][b]%26)%26)%26;
			}
		}
		for(a=0;a<3;a++)
			en[f++]=ans[a][0]%26+97;
	}
	f=l;
	en[f]='\0';
	printf("\nCipher text: %s\n",en);
	//Decryption
	findadj();
	int d=finddet();
	int din=modInverse(d);
	for(a=0;a<3;a++)
		for(b=0;b<3;b++)
			adj[a][b]=(adj[a][b]%26*din%26)%26;
	printf("\nMatrix inverse :\n");
	for(a=0;a<3;a++)
	{
		for(b=0;b<3;b++)
		{
			printf("%d\t",adj[a][b]);
		}
		printf("\n");
	}
	char de[100];
	i=0;
	f=0;
	while(i<l)
	{
		for(j=0;j<3;j++)
		{
			if(i<l)
				p[j][0]=en[i++]-97;
			else
				p[j][0]=25;
		}
		for(a=0;a<3;a++)
		{
			for(b=0;b<1;b++)
			{
				ans[a][b]=0;
				for(c=0;c<3;c++)
					ans[a][b]=((ans[a][b])%26+(adj[a][c]%26*p[c][b]%26)%26)%26;
			}
		}
		for(a=0;a<3;a++)
			de[f++]=ans[a][0]%26+97;
	}
	f=l;
	de[f]='\0';
	printf("\nPlain text: %s\n",s);
	return 0;
}
