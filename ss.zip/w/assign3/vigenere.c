//Vigenere Cipher
#include<stdio.h>
#include<string.h>

int main()
{
	char inpt[100],pt[100],ct[100],dt[100],key[100];
	printf("Enter the plaintext: ");
	scanf("%[^\n]s",inpt);
	int i,j,k,m;
	j=0;
	int l=strlen(inpt);
	for(i=0;i<l;i++)
	{
		if(inpt[i]!=' ')
		pt[j++]=inpt[i];

	}
	pt[j]='\0';
	printf("Enter the key:");
	scanf("%s",key);
	int kl=strlen(key);
	//Encryption
	k=0;
	for(i=0;i<j;i++)
	{
		m=pt[i]-97;
		ct[i]=((m+key[k++]-97)%26)+97;
		if(k==kl)
		k=0;
	}
	ct[j]='\0';
	printf("\nCipher Text is\n%s\n",ct);
	//Decryption
	l=strlen(ct);
	j=0,k=0;
	for(i=0;i<l;i++)
	{
		if((m=ct[i]-(key[k]-97))<97){

		dt[j++]=ct[i]-(key[k]-97)+26;
		k++;
		}

	else dt[j++]=ct[i]-(key[k++]-97);
	if(k==kl)
	k=0;

	}
	dt[j]='\0';
	printf("\nPlaintext after decryption:\n%s\n\n",dt);
	return 0;


}
