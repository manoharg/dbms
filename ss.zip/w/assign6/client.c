#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>

#define ll long long

ll mulmod(int a,int b,int m){
	ll ans=1;
	
	while(b>0){
	if(b%2==1)
	ans=(ans*a)%m;
	
	a=(a*a)%m;
	b>>=1;
	}
	return ans;
}

int main()
{   
    
    int csock,st;
	int g=10;
    struct sockaddr_in se,cl;
    
    csock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    
    if(csock == -1)
    {
        printf("Error c1\n");
        return 0;
    }
    
    
    se.sin_family = PF_INET;
    se.sin_port = htons(3000);
    se.sin_addr.s_addr = inet_addr("127.0.0.1");
    
    st = connect(csock, (struct sockaddr *)&se, sizeof(se));
    
    if(st==-1)
    {
        printf("Error c2\n");
        return 0;
    }
    int y;
    printf("Enter y:");
	scanf("%d",&y);
	
	ll b=mulmod(g,y,97);
	printf("Public key of B=%lld\n",b);
	char msg[10];
    int ret=recv(csock, msg, 10, 0);
    printf("%s\n",msg);
    int x=atoi(msg);
    ll key=mulmod(b,x,97);
    printf("Shared key=%lld\n",key);
    int d=1;
	while((key*d)%97!=1)
	d++;
	
    int m;
    printf("Enter message number:");
    scanf("%d",&m);
    m=(m*key)%97;
    sprintf(msg,"%d",m);
    printf("%d\n",m);
    send(csock,msg,10,0);
    sprintf(msg,"%d",d);
    send(csock,msg,10,0);
    close(csock);
    
    
    return 0;
}
