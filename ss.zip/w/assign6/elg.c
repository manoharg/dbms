#include<stdio.h>
#define ll long long
ll mulmod(int a,int b,int m){
	ll ans=1;
	
	while(b>0){
	if(b%2==1)
	ans=(ans*a)%m;
	
	a=(a*a)%m;
	b>>=1;
	}
	return ans;
}
int main(){
	int p=97,g=10;
	
	int x=rand()%97;
	int y=rand()%97;
	
	printf("x=%d y=%d\n",x,y);
	
	ll a=mulmod(g,x,p);
	ll b=mulmod(g,y,p);
	
	printf("Public key of A=%lld\n",a);
	printf("Public key of B=%lld\n",b);
	
	ll key1=mulmod(a,y,p);
	ll key2=mulmod(b,x,p);
	printf("Shared key at A=%lld\n",key1);
	printf("Shared key at B=%lld\n",key2);
	return 0;
	}
