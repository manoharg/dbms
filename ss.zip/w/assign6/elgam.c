#include<stdio.h>
#define ll long long
ll mulmod(int a,int b,int m){
	ll ans=1;
	
	while(b>0){
	if(b%2==1)
	ans=(ans*a)%m;
	
	a=(a*a)%m;
	b>>=1;
	}
	return ans;
}
int main(){
	int p=97,g=10;
	int x,y;
	printf("Enter x:");
	scanf("%d",&x);
	printf("Enter y:");
	scanf("%d",&y);
	
	ll a=mulmod(g,x,p);
	printf("Public key of A=%lld\n",a);
	
	ll key1=mulmod(a,y,p);
	printf("Shared key at A=%lld\n",key1);
	
	int d=1;
	while((key1*d)%p!=1)
	d++;
	
	printf("Inverse=%d\n",d);
	return 0;
	}
