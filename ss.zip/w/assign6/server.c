#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>

#define ll long long

ll mulmod(int a,int b,int m){
	ll ans=1;
	
	while(b>0){
	if(b%2==1)
	ans=(ans*a)%m;
	
	a=(a*a)%m;
	b>>=1;
	}
	return ans;
}

int main()
{   
    
    int ssock,st;
	int g=10;
    struct sockaddr_in se,cl;
    
    ssock = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
    
    if(ssock == -1)
    {
        printf("Error s1\n");
        return 0;
    }
    
    
    cl.sin_family = PF_INET;
    cl.sin_port = htons(3000);
    cl.sin_addr.s_addr = inet_addr("127.0.0.1");
    
    
    st = bind(ssock, (struct sockaddr *) &cl, sizeof(cl));
	
	if(st==-1)
	{
		printf("Error s2\n");
		return 0;
	}
    
    st = listen(ssock, 5);
    
    if(st==-1)
    {
        printf("Error s3\n");
        return 0;
    }
    
    int p = sizeof(cl);
    
    int s1 = accept(ssock, (struct sockaddr *)&cl, &p);
    
    if(s1 == -1)
    {
        printf("Error s4\n");
        return 0;
    }
    int x;
    printf("Enter x:");
    scanf("%d",&x);
    
    ll a=mulmod(g,x,97);
    printf("Public key of A=%lld\n",a);
    char msg[10];
    sprintf(msg,"%d",a);
    
    
    if(send(s1, msg, 10, 0) < 0)
    {
        printf("Error s5\n");
        return 0;
    }
	
    recv(s1,msg,10,0);
    
    ll m=atoi(msg);
    printf("%lld\n",m);
    recv(s1,msg,10,0);
    int d=atoi(msg);
    int ans=(m*d)%97;
    printf("Message=%d\n",ans);
    close(ssock);
    
    
    
    return 0;
}
