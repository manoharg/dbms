#include<bits/stdc++.h>
using namespace std;
#define ll long long

ll gcd(ll a, ll b)
{
	if(b%a==0)
		return a;
	return gcd(b%a,a);	
}

ll power(ll a, ll b, ll m)
{
	
	ll ret=1,i;
	
	for(i=0;i<b;i++)
		ret=ret*a%m;
	
	return ret;
}


// C function for extended Euclidean Algorithm
ll gcdExtended(ll a, ll b, ll *x, ll *y)
{
    // Base Case
    if (a == 0)
    {
        *x = 0, *y = 1;
        return b;
    }
 
    ll x1, y1; // To store results of recursive call
    ll gcd = gcdExtended(b%a, a, &x1, &y1);
 
    // Update x and y using results of recursive
    // call
    *x = y1 - (b/a) * x1;
    *y = x1;
 
    return gcd;
}
 
// Function to find modulo inverse of a
ll modInverse(ll a, ll m)
{
    ll x, y;
    ll g = gcdExtended(a, m, &x, &y);
    if (g != 1)
        return -1;
    else
    {
        // m is added to handle negative x
        ll res = (x%m + m) % m;
        return res;
    }
}

int main()
{
	
	ll i,j,k,m,n,q,phi,e,d,c,plain,plain2;

	ll p,g,x,a;
	ll y,b,c1,c2;
	
	
	//at reciever side
	p=10000007;
	g=2;
	x=67;		//private key
	a=power(g,x,p);
	
	printf("public key for A : (%lld,%lld,%lld)\n",p,g,a);
	printf("private key for A : (%lld)\n",x);
	printf("Plaintext : ");
	scanf("%lld",&plain);
	
	//at sender side
	y=45;
	c1=power(g,y,p);
	c2=power(a,y,p)*plain%p;
	printf("Encrypted: c1=%lld, c2=%lld\n",c1,c2);
	
	//at reciever side
	plain2=c2*modInverse(power(c1,x,p),p)%p;
	
	printf("decrypted msg : %lld\n",plain2);
	
	
	return 0;
}
