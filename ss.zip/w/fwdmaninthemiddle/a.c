#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<sys/types.h>
#include<sys/socket.h>
typedef long long int lint;
int main()
{
        int sersock;
        sersock=socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
        struct sockaddr_in se,cl;
        cl.sin_family = PF_INET;
        cl.sin_port=htons(8001);
        cl.sin_addr.s_addr=inet_addr("127.0.0.1");
        
        bind(sersock,(struct sockaddr *)&cl,sizeof(cl));
        
        listen(sersock,5);
        int p=sizeof(cl);
        //while(true)
        {
                int sock=accept(sersock,(struct sockaddr *)&cl,&p);
                char msg[10],msg2[10],msg3[10];
                recv(sock,msg,10,0);
                /*recv(sock,msg2,10,0);
                recv(sock,msg3,10,0);
                printf("%s %s %s\n",msg,msg2,msg3);*/
                lint k=atoi(msg);
                printf("%lld\n",k);
                lint mess=58;
                mess=mess*k;
                sprintf(msg,"%lld",mess);
                send(sock,msg,10,0);
                
        }
}
