#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<sys/types.h>
#include<sys/socket.h>
typedef long long int lint;
int main()
{
        int clisock;
        clisock=socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
        struct sockaddr_in se,cl;
        se.sin_family = PF_INET;
        se.sin_port=htons(8002);
        se.sin_addr.s_addr=inet_addr("127.0.0.1");
        
        //bind(sersock,(struct sockaddr *)&cl,sizeof(cl));
        
        //listen(sersock,5);
        //int p=sizeof(cl);
        int sock=connect(clisock,(struct sockaddr *)&se,sizeof(se));
        //while(true)
        {
                lint m,l,n;
                scanf("%lld",&m);
                char msg[10],msg2[10],msg3[10];
                sprintf(msg,"%lld",m);
                /*sprintf(msg2,"%lld",l);
                sprintf(msg3,"%lld",n);*/
                send(clisock,msg,10,0);
                /*send(clisock,msg2,10,0);
                send(clisock,msg3,10,0);*/
                recv(clisock,msg,10,0);
                lint j=atoi(msg);
                j=j/m;
                printf("%lld\n",j);
                
        }
}
