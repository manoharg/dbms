#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define N 10005

ll isnotprime[N];

void sieve()
{
	ll i,j,k;
	memset(isnotprime,0,sizeof(isnotprime));
	isnotprime[1]=1;		//1 means not prime
	
	for(i=2;i*i<=N;i++)
		for(j=2*i;j<=N;j+=i)
			isnotprime[j]=1;
}



int main()
{
	
	ll i,j,k,m,n,p,q,phi,e,d,c;
	
	sieve();
	
	p=0;
	q=0;
	
	for(i=N-1;i>=0;i--)
		if(isnotprime[i]==0)
			if(p==0)
				p=i;
			else if(q==0)
			{
				q=i;
				break;
			}
			else
				break;
	
	printf("private keys are p=%lld, q=%lld\n",p,q);
	n=p*q;
	printf("public key is n=%lld\n",n);
	
	
	return 0;
}