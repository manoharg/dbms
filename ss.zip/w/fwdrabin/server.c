#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>

#define ll long long

ll power(ll a, ll b, ll m)
{
	
	ll ret=1,i;
	
	for(i=0;i<b;i++)
		ret=ret*a%m;
	
	return ret;
}

// C function for extended Euclidean Algorithm
ll gcdExtended(ll a, ll b, ll *x, ll *y)
{
    // Base Case
    if (a == 0)
    {
        *x = 0, *y = 1;
        return b;
    }
 
    ll x1, y1; // To store results of recursive call
    ll gcd = gcdExtended(b%a, a, &x1, &y1);
 
    // Update x and y using results of recursive
    // call
    *x = y1 - (b/a) * x1;
    *y = x1;
 
    return gcd;
}

int main()
{   
    
    int ssock,st;
	
	ll p=9973, q=9967,n,i;
	n=p*q;
    
    struct sockaddr_in se,cl;
    
    ssock = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
    
    if(ssock == -1)
    {
        printf("Error s1\n");
        return 0;
    }
    
    
    cl.sin_family = PF_INET;
    cl.sin_port = htons(2000);
    cl.sin_addr.s_addr = inet_addr("127.0.0.1");
    
    
    st = bind(ssock, (struct sockaddr *) &cl, sizeof(cl));
	
	if(st==-1)
	{
		printf("Error s2\n");
		return 0;
	}
    
    st = listen(ssock, 5);
    
    if(st==-1)
    {
        printf("Error s3\n");
        return 0;
    }
    
    int pp = sizeof(cl);
    
    int s1 = accept(ssock, (struct sockaddr *)&cl, &pp);                                                 //new socket
    
    if(s1 == -1)
    {
        printf("Error s4\n");
        return 0;
    }
    
    char msg[10];
    int len = strlen(msg);
    
    if(recv(s1, msg, 10, 0) < 0)
    {
        printf("Error s5\n");
        return 0;
    }
	
	ll ms=atoi(msg);
    printf("Encrypted Message Recieved : %lld\n",ms);

    ll mp,mq,yp,yq;
    for(i=1;i<p;i++)
    	if(power(i,2,p)==(ms%p))
    	{
    		mp=i;
    		break;
    	}
    for(i=1;i<q;i++)
    	if(power(i,2,q)==(ms%q))
    	{
    		mq=i;
    		break;
    	}

    printf("Calculated mp=%lld, mq=%lld\n",mp,mq);

    gcdExtended(p,q,&yp,&yq);

    printf("Calculated yp=%lld, yq=%lld\n",yp,yq);
    yp=(yp+n)%n;
    yq=(yq+n)%n;

    ll r,rr,s,ss;
    r=(yp*p%n*mq%n+yq*q%n*mp%n)%n;
    rr=n-r;
    s=(yp*p%n*mq%n-yq*q%n*mp%n+n)%n;
    ss=n-s;

	printf("Decrypted Message is one of the following: %lld %lld %lld %lld\n",r,rr,s,ss);
    
    
    /*char s[10]="hello";
    len = strlen(s);
    
    if(send(s1, s, len, 0) != len)
    {
        printf("Error s6\n");
        return 0;
    }
    */
    close(ssock);
    
    
    
    return 0;
}