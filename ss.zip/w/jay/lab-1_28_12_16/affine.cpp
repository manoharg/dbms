//Affine cipher
#include<bits/stdc++.h>
using namespace std;


int power(int a,int b,int m)
{
	if(b==0)
		return 1;
	
	int tmp=power(a,b/2,m);
	
	tmp=tmp*tmp%m;
	
	if(b%2==0)
		return tmp;
	
	return tmp*a%m;
	
}

int char_to_int(char c)
{	
	if(c>='a' && c<='z')
		return c-'a';
	return c-'A';
}

char int_to_char(int p)
{
	return 'a'+(p+26)%26;
}

char int_to_charA(int p)
{
	return 'A'+(p+26)%26;
}

string encrypt(string plain,int k1,int k2)
{
	int l,i;
	string cipher="";
	l=plain.size();
	for(i=0;i<l;i++)
	{
		if(plain[i]>='A' && plain[i]<='Z')
			cipher+=int_to_charA(char_to_int(plain[i])*k1+k2);	
		else if(plain[i]>='a' && plain[i]<='z')
			cipher+=int_to_char(char_to_int(plain[i])*k1+k2);	
		else
			cipher+=plain[i];
	}
	return cipher;
	
}

string decrypt(string cipher,int k1,int k2)
{
	int l,i;
	string plain="";
	l=cipher.size();
	for(i=0;i<l;i++)
	{
		if(cipher[i]>='A' && cipher[i]<='Z')
			plain+=int_to_charA((char_to_int(cipher[i])+k2)*k1);	
		else if(cipher[i]>='a' && cipher[i]<='z')
			plain+=int_to_char((char_to_int(cipher[i])+k2)*k1);
		else
			plain+=cipher[i];
	}
	return plain;
	
}


int mul_inverse(int k,int m)
{
	int i;
	for(i=1;i<100;i++)
	{
		if((k*i)%m==1)	
			return i;
	}
	
}

/*
int mul_inverse(int k,int m)
{
	int i,j,n;
	
	
	return power(k,m-2,m);
	
}
*/

int add_inverse(int k,int m)
{	
	return m-k%m;
}


int main()
{
	
	
	//printf("%d %d\n",power(7,24,26),power(2,4,10));
	
	int i,j,m,n,l,k1,k2,k11,k22;
	string plain,cipher="",plain2;
	
	printf("Key : ");
	scanf("%d%d",&k1,&k2);
	
	printf("Plaintext : ");
	getchar();
	getline(cin,plain);
	
	cipher=encrypt(plain,k1,k2);
	
	cout << "Ciphertext : " << cipher << endl;
	
	
	k11=mul_inverse(k1,26);
	k22=add_inverse(k2,26);
	
	plain2=decrypt(cipher,k11,k22);
	cout << "Plaintext : " << plain2 << endl;
	

	
	
	return 0;
}
	
