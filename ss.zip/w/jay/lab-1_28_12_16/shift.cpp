//shift monoalphabatic cipher

#include<bits/stdc++.h>
using namespace std;

int char_to_int(char c)
{	
	if(c>='a' && c<='z')
		return c-'a';
	return c-'A';
}

char int_to_char(int p)
{
	return 'a'+(p+26)%26;
}

char int_to_charA(int p)
{
	return 'A'+(p+26)%26;
}

string encrypt(string plain,int k)
{
	int l,i;
	string cipher="";
	l=plain.size();
	for(i=0;i<l;i++)
	{
		if(plain[i]>='A' && plain[i]<='Z')
			cipher+=int_to_charA(char_to_int(plain[i])+k);	
		else if(plain[i]>='a' && plain[i]<='z')
			cipher+=int_to_char(char_to_int(plain[i])+k);	
		else
			cipher+=plain[i];
	}
	return cipher;
	
}

string decrypt(string cipher,int k)
{
	int l,i;
	string plain="";
	l=cipher.size();
	for(i=0;i<l;i++)
	{
		if(cipher[i]>='A' && cipher[i]<='Z')
			plain+=int_to_charA(char_to_int(cipher[i])+k);	
		else if(cipher[i]>='a' && cipher[i]<='z')
			plain+=int_to_char(char_to_int(cipher[i])+k);	
		else
			plain+=cipher[i];
	}
	return plain;
	
}

int add_inverse(int k,int m)
{	
	return m-k%m;
}



int main()
{
	
	int i,j,k,m,n,l,k2;
	string plain,cipher="",plain2;
	
	printf("Key : ");
	scanf("%d",&k);
	
	printf("Plaintext : ");
	getchar();
	getline(cin,plain);
	
	cipher=encrypt(plain,k);
	
	cout << "Ciphertext : " << cipher << endl;
	
	k2=add_inverse(k,26);
	plain2=decrypt(cipher,k2);
	cout << "Plaintext : " << plain2 << endl;
	

	
	
	return 0;
}
	
