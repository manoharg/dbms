//Substitution monoalphabatic cipher
#include<bits/stdc++.h>
using namespace std;
int char_to_int(char c)
{	
	if(c>='a' && c<='z')
		return c-'a';
	return c-'A';
}
char int_to_char(int p)
{
	return 'a'+(p+26)%26;
}
char int_to_charA(int p)
{
	return 'A'+(p+26)%26;
}
string encrypt(string plain,string k)
{
	int l,i;
	char c;
	map<char,char> M;
	string cipher="";
	l=plain.size();
	for(c='a';c<='z';c++)
	{
		if(k[c-'a']>='a' && k[c-'a']<='z')
			M[c]=k[c-'a'];
		else
			M[c]=k[c-'a']+32;
	}
	for(c='A';c<='Z';c++)
	{
		if(k[c-'A']>='A' && k[c-'A']<='z')
			M[c]=k[c-'A'];
		else
			M[c]=k[c-'A']-32;
	}
	for(i=0;i<l;i++)
	{
		if((plain[i]>='A' && plain[i]<='Z') || (plain[i]>='a' && plain[i]<='z'))
			cipher+=M[plain[i]];
		else
			cipher+=plain[i];
	}
	return cipher;
}
string decrypt(string cipher,string k)
{
	int l,i;
	char c;
	string plain="";
	l=cipher.size();
	map<char,char> M;
	for(c='a';c<='z';c++)
		M[k[c-'a']]=c;
	for(i=0;i<l;i++)
	{
		if((cipher[i]>='A' && cipher[i]<='Z') || (cipher[i]>='a' && cipher[i]<='z'))
			plain+=M[cipher[i]];
		else
			plain+=cipher[i];
	}
	return plain;
}

int add_inverse(int k,int m)
{	
	return m-k%m;
}

int main()
{	
	int i,j,m,n,l,k2;
	string plain,cipher="",plain2;
	string k;
	printf("Key : ");
	cin >> k;
	printf("Plaintext : ");
	getchar();
	getline(cin,plain);	
	cipher=encrypt(plain,k);	
	cout << "Ciphertext : " << cipher << endl;	
	plain2=decrypt(cipher,k);
	cout << "Plaintext : " << plain2 << endl;
	return 0;
}
	
