//auto key cipher
#include<bits/stdc++.h>
using namespace std;
int char_to_int(char c)
{	
	if(c>='a' && c<='z')
		return c-'a';
	return c-'A';
}
char int_to_char(int p)
{
	return 'a'+(p+26)%26;
}
char int_to_charA(int p)
{
	return 'A'+(p+26)%26;
}
string encrypt(string plain,string k)
{
	int l,i;
	string cipher="";
	l=plain.size();
	
	
	
	for(i=0;i<l;i++)
	{
		if(!((plain[i]>='a' && plain[i]<='z') || ((plain[i]>='A' && plain[i]<='Z'))))
			cipher+=plain[i];
		else
		{
			cipher+=int_to_charA((char_to_int(plain[i])+char_to_int(k[i]))%26);
			//k=char_to_int(plain[i]);
		}
	}
	return cipher;	
}

string decrypt(string cipher,string k)
{
	int l,i;
	string plain="";
	l=cipher.size();
	for(i=0;i<l;i++)
	{
		if(!((cipher[i]>='a' && cipher[i]<='z') || ((cipher[i]>='A' && cipher[i]<='Z'))))
			plain+=cipher[i];
		else
		{
			plain+=int_to_char((char_to_int(cipher[i])-char_to_int(k[i])+26)%26);
			//k=add_inverse(char_to_int(plain[i]),26);
		}
		
	}
	return plain;
	
}



int main()
{
	
	int i,j,m,n,l,k2;
	
	string plain,cipher="",plain2,k;
	
	printf("Key : ");
	cin >> k;
	
	printf("Plaintext : ");
	getchar();
	getline(cin,plain);
	
	l=plain.size();
	int lk=k.size();
	
	if(lk<l)
		k+=plain.substr(0,l-lk);
	
	cipher=encrypt(plain,k);
	
	cout << "Ciphertext : " << cipher << endl;
	
	plain2=decrypt(cipher,k);
	cout << "Plaintext : " << plain2 << endl;
	

	
	
	return 0;
}
	
