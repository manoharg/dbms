//playfair cipher

#include<bits/stdc++.h>
using namespace std;

int char_to_int(char c)
{	
	if(c>='a' && c<='z')
		return c-'a';
	return c-'A';
}

char int_to_char(int p)
{
	return 'a'+(p+26)%26;
}

char int_to_charA(int p)
{
	return 'A'+(p+26)%26;
}

string encrypt(string plain,char k[][5])
{
	int l,i,i1,i2,j1,j2;
	string cipher="";
	l=plain.size();
	
	//delete all space and other characters---------
	for(i=0;i<l;i++)
		if(!((plain[i]>='a' && plain[i]<='z') || ((plain[i]>='A' && plain[i]<='Z'))))
		{
			plain=plain.substr(0,i)+plain.substr(i+1,l-i-1);
			l--;
		}
	//---------------------------------------------
	
	for(i=0;i<l-1;i+=2)
	{
		if(plain[i]=='j')
			plain[i]='i';
		if(plain[i+1]=='j')
			plain[i+1]='i';
		if(plain[i]==plain[i+1])
		{	
			plain.insert(i+1,"x");
			l++;
		}
	}
	if(plain[l-1]=='j')
			plain[l-1]='i';
	if(l%2==1)
	{
		plain.insert(l,"x");
		l++;
	}
	
	//cout << plain;
	
	
	for(i=0;i<l-1;i+=2)
	{
		
		int ii1,jj1,ii2,jj2;
		
		for(i2=0;i2<5;i2++)
			for(j2=0;j2<5;j2++)
				if(k[i2][j2]==plain[i]-32)
				{
					ii1=i2;
					jj1=j2;
					break;
				}
		for(i2=0;i2<5;i2++)
			for(j2=0;j2<5;j2++)
				if(k[i2][j2]==plain[i+1]-32)
				{
					ii2=i2;
					jj2=j2;
					break;
				}
		
		
		//printf("%d %d %d %d\n",ii1,jj1,ii2,jj2);
		
		if(ii1==ii2)
		{
			cipher+=k[ii1][(jj1+1)%5];
			cipher+=k[ii2][(jj2+1)%5];
		}
		else if(jj1==jj2)
		{
			cipher+=k[(ii1+1)%5][jj1];
			cipher+=k[(ii2+1)%5][jj2];
		}
		else
		{
			cipher+=k[ii1][jj2];
			cipher+=k[ii2][jj1];
			
		}
		
	}

	
	return cipher;
	
	
}

string decrypt(string cipher,char k[][5])
{
	int l,i,i1,i2,j1,j2;
	string plain="";
	l=cipher.size();
	
	
	
	for(i=0;i<l-1;i+=2)
	{
		
		int ii1,jj1,ii2,jj2;
		
		for(i2=0;i2<5;i2++)
			for(j2=0;j2<5;j2++)
				if(k[i2][j2]==cipher[i])
				{
					ii1=i2;
					jj1=j2;
					break;
				}
		for(i2=0;i2<5;i2++)
			for(j2=0;j2<5;j2++)
				if(k[i2][j2]==cipher[i+1])
				{
					ii2=i2;
					jj2=j2;
					break;
				}
		
		
		//printf("%d %d %d %d\n",ii1,jj1,ii2,jj2);
		
		if(ii1==ii2)
		{
			plain+=k[ii1][(jj1-1+5)%5]+32;
			plain+=k[ii2][(jj2-1+5)%5]+32;
		}
		else if(jj1==jj2)
		{
			plain+=k[(ii1-1+5)%5][jj1]+32;
			plain+=k[(ii2-1+5)%5][jj2]+32;
		}
		else
		{
			plain+=k[ii1][jj2]+32;
			plain+=k[ii2][jj1]+32;
			
		}
		
	}
	
	
	for(i=0;i<l;i++)
	{
		
		if(plain[i]=='x')
		{
			plain=plain.substr(0,i)+plain.substr(i+1,l-i-1);;
			l--;
		}
	}
	
	
	
	

	
	return plain;
	
	
}


int main()
{
	
	int i,j,m,n,l,k2,i1;
	char k[5][5],c;
	string plain,cipher="",plain2;
	
	c='A';
	for(i1=4;i1>=-4;i1--)
	{
		for(i=0,j=i1;;i++,j++)
		{
			if(!(i>=0 && j>=0 && i<=4 && j<=4))
				continue;
			
		//	printf("%d %d\n",i,j);
			k[i][j]=c;
			
			c++;
			if(c=='J')
				c++;
					
			if(i==4 || j==4)
				break;
			
		}
	}
	
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
			printf("%c ",k[i][j]);
		printf("\n");
	}
	

	printf("Plaintext : ");
	//getchar();
	getline(cin,plain);
	
	cipher=encrypt(plain,k);
	
	cout << "Ciphertext : " << cipher << endl;
	
	plain2=decrypt(cipher,k);
	cout << "Plaintext : " << plain2 << endl;
	
	
	
	return 0;
}
	
