//vignere
#include<bits/stdc++.h>
using namespace std;

#define N 3




//copied from geeks -------------------------------------------------------------------------------------------------------------------------
void getCofactor(int A[N][N], int temp[N][N], int p, int q, int n)
{
    int i = 0, j = 0;
 
    // Looping for each element of the matrix
    for (int row = 0; row < n; row++)
    {
        for (int col = 0; col < n; col++)
        {
            //  Copying into temporary matrix only those element
            //  which are not in given row and column
            if (row != p && col != q)
            {
                temp[i][j++] = A[row][col];
 
                // Row is filled, so increase row index and
                // reset col index
                if (j == n - 1)
                {
                    j = 0;
                    i++;
                }
            }
        }
    }
}
 
/* Recursive function for finding determinant of matrix.
   n is current dimension of A[][]. */
int determinant(int A[N][N], int n)
{
    int D = 0; // Initialize result
 
    //  Base case : if matrix contains single element
    if (n == 1)
        return A[0][0];
 
    int temp[N][N]; // To store cofactors
 
    int sign = 1;  // To store sign multiplier
 
     // Iterate for each element of first row
    for (int f = 0; f < n; f++)
    {
        // Getting Cofactor of A[0][f]
        getCofactor(A, temp, 0, f, n);
        D += sign * A[0][f] * determinant(temp, n - 1);
 
        // terms are to be added with alternate sign
        sign = -sign;
    }
 
    return D;
}
 
// Function to get adjoint of A[N][N] in adj[N][N].
void adjoint(int A[N][N],int adj[N][N])
{
    if (N == 1)
    {
        adj[0][0] = 1;
        return;
    }
 
    // temp is used to store cofactors of A[][]
    int sign = 1, temp[N][N];
 
    for (int i=0; i<N; i++)
    {
        for (int j=0; j<N; j++)
        {
            // Get cofactor of A[i][j]
            getCofactor(A, temp, i, j, N);
 
            // sign of adj[j][i] positive if sum of row
            // and column indexes is even.
            sign = ((i+j)%2==0)? 1: -1;
 
            // Interchanging rows and columns to get the
            // transpose of the cofactor matrix
            adj[j][i] = (sign)*(determinant(temp, N-1));
        }
    }
}
 
// Function to calculate and store inverse, returns false if
// matrix is singular
bool inverse(int A[N][N], int inverse[N][N])
{
    // Find determinant of A[][]
    int det = determinant(A, N);
    if (det == 0)
    {
        cout << "Singular matrix, can't find its inverse";
        return false;
    }
 
    // Find adjoint
    int adj[N][N];
    adjoint(A, adj);
    printf("*%d*",det);
    // Find Inverse using formula "inverse(A) = adj(A)/det(A)"
    for (int i=0; i<N; i++)
        for (int j=0; j<N; j++)
        printf("%d ",adj[i][j]),
            inverse[i][j] = adj[i][j]/det;
    
    return true;
}


//-------------------------------------------------------------------------------------------------------------------------

int char_to_int(char c)
{	
	if(c>='a' && c<='z')
		return c-'a';
	return c-'A';
}

char int_to_char(int p)
{
	return 'a'+(p+26)%26;
}

char int_to_charA(int p)
{
	return 'A'+(p+26)%26;
}

int ans[N];
void multiply(int k[N][N],int p[N])
{
    
    int i,j,ret=0;
    
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            
            ret+=k[i][j]*p[j];
            
        }
        
        ans[i]=ret%26;
        ret=0;
        
    }
    
}

string encrypt(string plain,int k[N][N])
{
	int l,lk,i,i1,i2,j1,j2,j;
	string cipher="";
	l=plain.length();
    int p[N];
	
	//append x
    while(l%N!=0)
    {
        plain+='x';
        l=plain.length();
    }
    
    
	for(i=0,j=0;i<l;i++,j++)
	{
	    p[j]=char_to_int(plain[i]);
	    if(j==N-1)
	    {
		    multiply(k,p);
		    for(j=0;j<N;j++)
        		cipher+=int_to_char(ans[j]);
    		
    		j=-1;
    	}
	}
	
	return cipher;
	
}


int main()
{
	
	int i,j,m,l,i1;
	string plain,cipher="",plain2="";
	

	printf("Plaintext : ");
	//getchar();
	getline(cin,plain);
	
	/*
	printf("size of Key-matrix : ");
	scanf("%d",&n);
	*/
	int k[N][N];
	int k2[N][N];
	
	printf("Key-matrix : ");
	for(i=0;i<N;i++)
	    for(j=0;j<N;j++)
	        scanf("%d",&k[i][j]);
    
	
	cipher=encrypt(plain,k);
	cout << cipher;
	/*
	inverse(k,k2);
	
	for(i=0;i<N;i++)
	for(j=0;j<N;j++)
	printf("%lf ",k2[i][j]);
	
//	plain2=decrypt(cipher,k2);
    */
	cout << "\nPlaintext is : "<<plain << "\n";	       //cheater
	
	return 0;
}
	
