//vignere
#include<bits/stdc++.h>
using namespace std;

int char_to_int(char c)
{	
	if(c>='a' && c<='z')
		return c-'a';
	return c-'A';
}

char int_to_char(int p)
{
	return 'a'+(p+26)%26;
}

char int_to_charA(int p)
{
	return 'A'+(p+26)%26;
}

string encrypt(string plain,string k)
{
	int lp,lk,i,i1,i2,j1,j2,j;
	string cipher="";
	lp=plain.size();
	lk=k.size();
	
	
	for(i=0,j=0;i<lp;i++,j=(j+1)%lk)
	{
		if(((plain[i]>='a' && plain[i]<='z') || ((plain[i]>='A' && plain[i]<='Z'))))
		    cipher+=int_to_char((char_to_int(plain[i])+char_to_int(k[j]))%26);
		else
		    cipher+=plain[i];
	}
	
	return cipher;
	
}

string decrypt(string cipher,string k)
{
	int lc,lk,i,i1,i2,j1,j2,j;
	string plain="";
	lc=cipher.size();
	lk=k.size();
	
	
	for(i=0,j=0;i<lc;i++,j=(j+1)%lk)
	{
		if(((cipher[i]>='a' && cipher[i]<='z') || ((cipher[i]>='A' && cipher[i]<='Z'))))
		    plain+=int_to_char((char_to_int(cipher[i])-char_to_int(k[j])+26)%26);
		else
		    plain+=cipher[i];
	}
	
	return plain;
	
}


int main()
{
	
	int i,j,m,n,l,k2,i1;
	string k;
	string plain,cipher="",plain2;
	

	printf("Plaintext : ");
	//getchar();
	getline(cin,plain);
	
	printf("Key : ");
	//getchar();
	getline(cin,k);
	
	cipher=encrypt(plain,k);
	
	cout << "Ciphertext : " << cipher << endl;
	
	plain2=decrypt(cipher,k);
	cout << "Plaintext : " << plain2 << endl;
	
	
	
	return 0;
}
	
