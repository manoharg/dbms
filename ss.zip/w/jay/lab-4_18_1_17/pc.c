#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>

int main()
{
int s,c;
struct sockaddr_in sc,cl;
s=socket(PF_INET,SOCK_STREAM,0);
if(s==-1)
{
printf("Error in creating socket\n");
}


sc.sin_family=PF_INET;
sc.sin_port=htons(2000);
sc.sin_addr.s_addr=inet_addr("127.0.0.1");


connect(s,(struct sockaddr *)&sc,sizeof(sc));
char msg[10]="hello";
send(s,msg,strlen(msg),0);
printf("%s",msg);
}
