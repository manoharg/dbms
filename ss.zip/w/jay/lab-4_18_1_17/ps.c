#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>

int main()
{
int s,c;
struct sockaddr_in sc,cl;
s=socket(PF_INET,SOCK_STREAM,0);
if(s==-1)
{
printf("Error in creating socket\n");
}


sc.sin_family=PF_INET;
sc.sin_port=htons(2000);
sc.sin_addr.s_addr=inet_addr("127.0.0.1");

bind(s,(struct sockaddr *)&sc,sizeof(sc));
listen(s,5);
int p=sizeof(sc);
c=accept(s,(struct sockaddr *)&sc,&p);
char msg[10];
recv(c,msg,10,0);
printf("%s",msg);
}
