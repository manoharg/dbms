#include<bits/stdc++.h>
using namespace std;
int mki(int i)
{
	int j=1;
	
	for(j=1;j<26;j++)
	{
	if( (i*j )%26==1)
	return j;
	}
	
	return j;
}
int main()
{
	string pt,ct,npt;
	int i,mk;
	cout<<"Enter text:";
	getline(cin,pt);
	int l;
	l=pt.length();
	int add,mul;
	while(1){
	cout<<"Enter add and mul key:";
	cin>>add>>mul;
	if(__gcd(mul,26)==1)
	break;
	
	
	}

ct="";
	
	for(i=0;i<l;i++)
	{
	if(pt[i]==' ')
	{
	
	ct+='#';
	}
	else
	{
		ct+=((pt[i]-'a')*mul+add)%26+'a';
		
	}
	
	}
	cout<<"Cipher is :"<<ct<<endl;
	mk=mki(mul);
	cout<<mk<<endl;
	npt="";
	for(i=0;i<l;i++)
	{
	
	if(ct[i]=='#')
	npt+=' ';
	else
	npt+=(((ct[i]-'a')-add%26+260)*mk)%26+'a';
		
	}
		
	cout<<npt<<endl;
	
	
		
}
