#include<bits/stdc++.h>
using namespace std;

int main()
{
	string pt,ct,npt;
	int i,mk;
	cout<<"Enter text:";
	getline(cin,pt);
int l;	
	l=pt.length();
	int add,mul;
	string k;

 l=pt.length();
for(i=0;i<l;i++)
{
	if(pt[i]==' ')
	{pt.erase(pt.begin()+i);
	i--;
	}
}
cout<<"Enter key:"<<endl;
cin>>k;
if(k.length()<pt.length())
{
k+=pt.substr(0,pt.length()-k.length());
}
cout<<k<<endl;
ct="";
	
	/*for(i=0;i<l;i++)
	{
	if(pt[i]==' ')
	{
	
	ct+='#';
	}
	else
	{
		ct+=k[(pt[i]-'a')];
		
	}
	
	}
	cout<<"Cipher is :"<<ct<<endl;

//	cout<<mk<<endl;
	npt="";
	for(i=0;i<l;i++)
	{
	
	if(ct[i]=='#')
	npt+=' ';
	else
	npt+=m[ct[i]];
		
	}
		
	cout<<npt<<endl;
	
	
*/		
}
