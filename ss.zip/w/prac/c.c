#include<bits/stdc++.h>
using namespace std;
#define ll long long int
bool isp(ll i)
{	ll j;
if(i<2)
return 0;
	for(j=2;j<i;j++)
	{
		if( (i%j) ==0)
		return 0;
	}
	return 1;
}
ll pp(ll m , ll e, ll n)
{
	ll i,j=1;
	for(i=1;i<=e;i++)
	{
		j=(j*m)%n;
	}
	return j;
	
}
int main ()
{





srand(time(NULL));
ll p,n,q,phi,e,d,m,c;
while(1)
{
	p=rand()%10000;
	if(isp(p))
	break;
}
while(1)
{
	q=rand()%10000;
	if(isp(q))
	break;
}
n=p*q;
cout<<p<<' '<<q<<endl;
phi=(p-1)*(q-1);
e=2;

while(1)
{
	if(__gcd(e,phi)==1)
	break;
	else
	e++;
}
//cin>>m;
for(d=1;d<phi;d++)
{
if( ( (e*d)%phi)==1)
break;
}
//cout<<"d"<<d<< "dsf"<<(e*d)%phi<<endl;
int s,c;
	s=socket(PF_INET,SOCK_STREAM,0);
	struct sockaddr_in ser,cli;
	
	ser.sin_family=PF_INET;
	ser.sin_port = htons(7777);
	ser.sin_addr.s_addr=inet_addr("127.0.0.1");
	
	
	connect(s,(struct sockaddr *)&ser,sizeof(ser));
	char msg[100];
	sprintf(msg,"%lld",e);
	cout<<msg<<endl;
	sprintf(msg,"%lld",n);
	send(s,msg,strlen(msg),0);
	while(1)
	{
		scanf("%s",msg);		
	send(s,msg,strlen(msg),0);
	
		int r=recv(s,msg,100,0);
		printf("%s",msg);
				
	}
	close(s);
	
}

