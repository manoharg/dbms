#include<bits/stdc++.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<string.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<netinet/in.h>
#include<sys/types.h>
using namespace std;
#define ll long long int
bool isp(ll i)
{	ll j;
if(i<2)
return 0;
	for(j=2;j<i;j++)
	{
		if( (i%j) ==0)
		return 0;
	}
	return 1;
}
ll pp(ll m , ll e, ll n)
{
	ll i,j=1;
	for(i=1;i<=e;i++)
	{
		j=(j*m)%n;
	}
	return j;
	
}
int main ()
{

srand(time(NULL));
ll p,n,q,phi,e,d,m,c;
while(1)
{
	p=rand()%1000;
	if(isp(p))
	break;
}
while(1)
{
	q=rand()%1000;
	if(isp(q))
	break;
}
n=p*q;

phi=(p-1)*(q-1);
e=2;

while(1)
{
	if(__gcd(e,phi)==1)
	break;
	else
	e++;
}
//cin>>m;
for(d=1;d<phi;d++)
{
if( ( (e*d)%phi)==1)
break;
}
cout<<e<<' '<<n<<endl;
cout<<"before sending::"<<endl;

//cout<<"d"<<d<< "dsf"<<(e*d)%phi<<endl;
        int s;
	s=socket(PF_INET,SOCK_STREAM,0);
	struct sockaddr_in ser,cli;
	
	ser.sin_family=PF_INET;
	ser.sin_port = htons(7777);
	ser.sin_addr.s_addr=inet_addr("127.0.0.1");
	
	
	connect(s,(struct sockaddr *)&ser,sizeof(ser));
	char msg[100];
	
	sprintf(msg,"%lld",e);
	
	send(s,msg,strlen(msg),0);
	sleep(1);
	cout<<msg<<"sent"<<endl;
	
	sprintf(msg,"%lld",n);
	
	send(s,msg,strlen(msg),0);
	sleep(1);
	cout<<msg<<"sent"<<endl;
	
		scanf("%s",msg);		
	send(s,msg,strlen(msg)+1,0);
	sleep(1);
		int r=recv(s,msg,100,0);
		sleep(1);
		printf("cipher is %s \n",msg);
		
		ll np=atoll(msg);
		np=pp(np,d,n);
		cout<<np<<endl;
		
				
	
	close(s);
	
}

