#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
int main()
{
	struct sockaddr_in csocket,ssocket;
	int file_des,flag,i,j;
	char temp;
	char msg2[1000];
	int recv_status;
	int cl;
	int new_sock_id;
	int send_status;
	file_des=socket(PF_INET,SOCK_STREAM,0);
	if(file_des<0)
	{
		printf("Socket creation failed!!!\n");
		return 0;
	}
	ssocket.sin_family=AF_INET;
	ssocket.sin_port=htons(5056);
	ssocket.sin_addr.s_addr=inet_addr("127.0.0.1");
	printf("Binding\n");
	bind(file_des,(struct sockaddr *)&ssocket,sizeof(ssocket));
	printf("Bound the socket\n");
	printf("Listening\n");
	int listen_status=listen(file_des,4);
	if(listen_status<0)
	{
		printf("Error in listening\n");
		return 1;
	}
	while(1)
	{
		cl=sizeof(csocket);
		new_sock_id=accept(file_des,(struct sockaddr *)&csocket,&cl);
		if(new_sock_id == -1)
		{
			return 1;
		}
		printf("\nAccepted\n");
		if(fork()==0)
		{
			
			close(file_des);
			while(1)
			{
				fflush(stdout);
				recv_status=recv(new_sock_id,msg2,199,0);
				printf("\nReceived bytes : %d",recv_status);
				printf("\nReceived string : %s",msg2);
				i = 0;
               			j = strlen(msg2) - 1;
               			
               			while(i<j)
                		{
                        	      temp = msg2[i];
                        	      msg2[i] = msg2[j];
                        	      msg2[j] = temp;
                        	      i++; 
                        	      j--;
                   		}
 
        			//printf("Sending\n");
				send_status=send(new_sock_id,msg2,strlen(msg2)+1,0);
				if(send_status<0)
				{
					printf("Not sent\n");
					return 1;
				}
				printf("\nString sent : %s",msg2);
			}
			close(new_sock_id);		
		}close(new_sock_id);
	}
	close(file_des);
	return 0;
}
	
