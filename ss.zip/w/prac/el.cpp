#include<bits/stdc++.h>
using namespace std;
#define ll long long int
ll power(ll m , ll e, ll n)
{
	ll i,j=1;
	for(i=1;i<=e;i++)
	{
		j=(j*m)%n;
	}
	return j;
	
} 
ll gen(ll p)
{
	ll i,j,f;
	for(i=2;i<p;i++)
	{
		f=0;
		ll h[p+1]={0};
		for(j=0;j<=p-2;j++)
		{
			int temp=power(i,j,p);
			if(h[temp]!=0)
			{f=1;
			break;
			}else
			h[temp]=1;
			
		}
		if(f==0)
		return i;
	}
	
}
bool isp(ll i)
{	ll j;
if(i<2)
return 0;
	for(j=2;j<i;j++)
	{
		if( (i%j) ==0)
		return 0;
	}
	return 1;
}

int main()
{

srand(time(NULL));
ll p,g,alp,k,r,d;
while(1)
{
	p=rand()%10000;
	if(isp(p))
	break;
}

g=gen(p);
cout<<p<<' '<<g<<endl;
d=rand()%(p-4);
alp=power(g,d,p);
ll c1,c2;
k=rand()%(p-4);
ll m;
cout<<"plain\n";
c1=power(g,k,p);
cin>>m;
ll temp;
temp=power(alp,k,p);
c2=(temp*m)%p;
cout<<"c1 , c2 is :"<<c1<<' '<<c2<<endl;
ll x=1;
while(((x*c1)%p)!=1)
x++;
ll plain=((c2%p)*(power(x,d,p))%p)%p;
cout<<plain<<endl;



}
