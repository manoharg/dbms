#include<bits/stdc++.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<string.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<netinet/in.h>
#include<sys/types.h>
using namespace std;
#define ll long long int
ll power(ll m , ll e, ll n)
{
	ll i,j=1;
	for(i=1;i<=e;i++)
	{
		j=(j*m)%n;
	}
	return j;
	
} 
ll gen(ll p)
{
	ll i,j,f;
	for(i=2;i<p;i++)
	{
		f=0;
		ll h[p+1]={0};
		for(j=0;j<=p-2;j++)
		{
			int temp=power(i,j,p);
			if(h[temp]!=0)
			{f=1;
			break;
			}else
			h[temp]=1;
			
		}
		if(f==0)
		return i;
	}
	
}
bool isp(ll i)
{	ll j;
if(i<2)
return 0;
	for(j=2;j<i;j++)
	{
		if( (i%j) ==0)
		return 0;
	}
	return 1;
}

int main ()
{


srand(time(NULL));
ll p,g,alp,k,r,d;
while(1)
{
	p=rand()%10000;
	if(isp(p))
	break;
}

g=gen(p);



d=rand()%(p-4);

alp=power(g,d,p);
/*ll c1,c2;

k=rand()%(p-4);
ll m;
cout<<"plain\n";
/c1=power(g,k,p);
cin>>m;
ll temp;
temp=power(alp,k,p);
c2=(temp*m)%p;
cout<<"c1 , c2 is :"<<c1<<' '<<c2<<endl;
ll x=1;
while(((x*c1)%p)!=1)
x++;
ll plain=((c2%p)*(power(x,d,p))%p)%p;
cout<<plain<<endl;
*/
//cout<<"d"<<d<< "dsf"<<(e*d)%phi<<endl;
        int s;
	s=socket(PF_INET,SOCK_STREAM,0);
	struct sockaddr_in ser,cli;
	
	ser.sin_family=PF_INET;
	ser.sin_port = htons(7777);
	ser.sin_addr.s_addr=inet_addr("127.0.0.1");
	
	
	connect(s,(struct sockaddr *)&ser,sizeof(ser));
	char msg[100];
	
	sprintf(msg,"%lld",p);
	
	send(s,msg,strlen(msg),0);
	//fflush(s);
	sleep(1);
	cout<<msg<<"sent"<<endl;
	//
	
	sprintf(msg,"%lld\n",g);
	
	send(s,msg,strlen(msg),0);
	sleep(1);
	cout<<msg<<"sent"<<endl;
	//
	sprintf(msg,"%lld\n",alp);
	
	send(s,msg,strlen(msg),0);
	cout<<msg<<"sent"<<endl;
		sleep(1);
	
	cout<<"Enter text:\n";
		scanf("%s",msg);		
	send(s,msg,strlen(msg)+1,0);
		sleep(1);
		r=recv(s,msg,100,0);
			sleep(1);printf("cipher is %s \n",msg);
		
		ll c1=atoll(msg);
	 r=recv(s,msg,100,0);
	 	sleep(1);
ll c2=atoll(msg);
cout<<c2<<endl;
	ll x=1;
while(((x*c1)%p)!=1)
x++;
ll plain=((c2%p)*(power(x,d,p))%p)%p;
cout<<plain<<endl;
	
	close(s);
	
}

