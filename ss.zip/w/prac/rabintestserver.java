import java.io.*;

import java.net.*;

import java.math.BigInteger;

import java.nio.charset.Charset;

public class rabintestserver {

public static void main(String[] args) throws UnsupportedEncodingException,IOException {



ServerSocket serverSocket = new ServerSocket(5000);

Socket clientSocket = serverSocket.accept();

BufferedReader is=new BufferedReader(new InputStreamReader(

clientSocket.getInputStream()));

PrintStream os = new PrintStream(clientSocket.getOutputStream());

BigInteger[] key = rabin.genKey(512);

BigInteger N = key[0];

BigInteger p = key[1];

BigInteger q = key[2];



System.out.println("Public Key N: "+N);

System.out.println("Private Key P: "+p);

System.out.println("Private Key Q: "+q);



os.println(N.toString());

BigInteger c=new BigInteger(is.readLine());

System.out.println("Encrypted String received from client is: "+c);

BigInteger[] m2 = rabin.decrypt(c, p, q);

for(BigInteger b:m2) {

String dec = new String(b.toByteArray(), Charset.forName("ascii"));

System.out.println("Decrypted String is: "+dec);

}

is.close();

os.close();

serverSocket.close();

clientSocket.close();

}

}
