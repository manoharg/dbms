#include<bits/stdc++.h>
using namespace std;
#define ll long long int
bool isp(ll i)
{	ll j;
if(i<2)
return 0;
	for(j=2;j<i;j++)
	{
		if( (i%j) ==0)
		return 0;
	}
	return 1;
}
ll pp(ll m , ll e, ll n)
{
	ll i,j=1;
	for(i=1;i<=e;i++)
	{
		j=(j*m)%n;
	}
	return j;
	
}
int main()
{

srand(time(NULL));
ll p,n,q,phi,e,d,m,c;
while(1)
{
	p=rand()%10000;
	if(isp(p))
	break;
}
while(1)
{
	q=rand()%10000;
	if(isp(q))
	break;
}
n=p*q;
cout<<p<<' '<<q<<endl;
phi=(p-1)*(q-1);
e=2;
cout<<"e:"<<e<<endl;;
while(1)
{
	if(__gcd(e,phi)==1)
	break;
	else
	e++;
}
d=1;
cin>>m;
for(d=1;d<phi;d++)
{
if( ( (e*d)%phi)==1)
break;
}
cout<<"d"<<d<< "dsf"<<(e*d)%phi<<endl;

c=pp(m,e,n);
cout<<"Cipher:"<<c<<endl;
ll np=pp(c,d,n);
cout<<"plain:"<<np<<endl;
}
