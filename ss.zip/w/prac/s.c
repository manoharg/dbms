#include<bits/stdc++.h>
#include<stdlib.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/socket.h>
#include<string.h>
#include<netinet/in.h>
#include<sys/types.h>
using namespace std;
int main ()
{


	int s,c;
	s=socket(PF_INET,SOCK_STREAM,0);
	struct sockaddr_in ser,cli;
	
	ser.sin_family=PF_INET;
	ser.sin_port = htons(7777);
	ser.sin_addr.s_addr=inet_addr("127.0.0.1");
	
	
	int p=bind(s,(struct sockaddr *)&ser,sizeof(ser));
	if(p==-1)
	{
		printf("Bind Error\n");
		return 0;
		
	}
	
	listen(s,5);
	char msg[100];
	while(1)
	{
		int q=sizeof(cli);
		c=accept(s,(struct sockaddr *)&cli, &q);	
			int r=recv(c,msg,100,0);
					ll e=atoll(msg);
					cout<<e<<endl;
					
					int r=recv(c,msg,100,0);
					ll n=atoll(msg);
					
					cout<<n<<endl;
					int r=recv(c,msg,100,0);
					if(r<0)
					break;
					
					
					
					printf("From client: %s\n",msg);
					send(c,msg,strlen(msg),0);
					
					
	close(c);
		
	}
	close(s);
	
}
