#include<bits/stdc++.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<string.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<netinet/in.h>
#include<sys/types.h>
using namespace std;
#define ll long long int
ll pp(ll m , ll e, ll n)
{
	ll i,j=1;
	for(i=1;i<=e;i++)
	{
		j=(j*m)%n;
	}
	return j;
	
}
int main ()
{


	int s,c,r;
	socklen_t sss;
	s=socket(PF_INET,SOCK_STREAM,0);
	struct sockaddr_in ser,cli;
	
	ser.sin_family=PF_INET;
	ser.sin_port = htons(7777);
	ser.sin_addr.s_addr=inet_addr("127.0.0.1");
	
	
	ll p=bind(s,(struct sockaddr *)&ser,sizeof(ser));
	if(p==-1)
	{
		printf("Bind Error\n");
		return 0;
		
	}
	
	listen(s,5);
	char msg[100],msg1[100];
	
	sss=sizeof(cli);
	c=accept(s,(struct sockaddr *)&cli, &sss);	
	
	r=recv(c,msg,100,0);
	
	ll e=atoll(msg);
	
	cout<<"e is "<<e<<endl;
	
	r=recv(c,msg1,100,0);
	sleep(1);
	ll n=atoll(msg1);
	cout<<"n is "<<n<<endl;
	
	 recv(c,msg,100,0);
	 sleep(1);
	 p=atoll(msg);
	printf("From client msg : %s\n",msg);
	p=pp(p,e,n);
	sprintf(msg,"%lld",p);
	cout<<msg<<endl;
	send(c,msg,strlen(msg),0);
		sleep(1);			
					
	close(c);
		
	
	close(s);
	
}
