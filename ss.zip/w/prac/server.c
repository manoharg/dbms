#include<stdio.h>
#include<sys/types.h>
#include<string.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<netinet/in.h>
int main()
{
	int ss, cs;
	ss=socket(PF_INET, SOCK_STREAM,0);
	if(ss==-1)
	{
		printf("-1\n");
	}
	struct sockaddr_in serv,cli;
	serv.sin_family=PF_INET;
	serv.sin_port=htons(8888);
	serv.sin_addr.s_addr=inet_addr("127.0.0.1");
	
	int p=bind(ss,(struct sockaddr *)&serv,sizeof(serv));
	if(p==-1)
	{printf("binding failed\n"); return 0;}
	listen(ss,5);
	printf("Binding succes\n");
	p=sizeof(cli);


	 //printf("Connection Accepted\n");
char msg[100];
int rs;
while(1)
{
cs=accept(ss,(struct sockaddr *)&cli,&p);

rs=recv(cs,msg,100,0);
	
		
		//recv(cs,msg,100,0);
printf("from client: %s\n",msg);
//printf("read\n");
send(cs,msg,strlen(msg),0);		
}

close(cs);
close(ss);			
	
	
	
}
