#include<stdio.h>
#include<sys/socket.h>
#include<string.h>
#include<netinet/in.h>
#include<sys/types.h>
#define ll long long int
ll isPrime[1000005];
ll a[100005];
ll k=0;
void init(){
 ll i,j;
 for(i=2;i*i<=1000005;i++){
 if(isPrime[i]==0){
 for(j=i*i;j<=1000005;j+=i){
 isPrime[i]=1;
 }
 }
 }
 
 for(i=2;i<=10005;i++){
  if(isPrime[i]==0)
  a[k++]=i;
  }
 }
ll summod(ll a,ll b,ll m){
	ll res=0;
	while(b>0){
	if(b%2)
	res=(res+a)%m;
	a=(a*2)%m;
	b>>=1;
	}
	return res;
}
ll mulmod(ll a,ll b,ll m){
	ll res=1;
	a=a%m;
	while(b>0){
	if(b%2)
	res=(summod(res,a,m))%m;
	
	a=(summod(a,a,m))%m;
	b>>=1;
	}
	return res%m;
}

ll gcd(ll a,ll b){
 if(b==0)
 return a;
 return gcd(b,a%b);
 }
 
int main(){
   init();
   srand(time(NULL));
   ll p=a[rand()%(k)];
   ll q=a[rand()%(k)];
  
   ll n=p*q;
   
   ll phi=(p-1)*(q-1);
   
   ll e=2;
   
   while(gcd(e,phi)!=1)
   e++;
   
   
   ll d=1;
   while(((e*d)%phi)!=1)
   d++;
   
   printf("%lld %lld %lld %lld\n",n,e,d,(e*d)%phi);
   
   int csock;
   struct sockaddr_in se;
   csock = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
   
   se.sin_family=PF_INET;
   se.sin_port=htons(4000);
   se.sin_addr.s_addr=inet_addr("127.0.0.1");
   
   int acpt=connect(csock,(struct sockaddr *)&se,sizeof(se));
   char nval[25],ans[25],nval2[25];
   sprintf(nval,"%lld",n);
   sprintf(nval2,"%lld",e);
   send(csock,nval,25,0);
   sleep(1);
   send(csock,nval2,25,0);
   sleep(1);
   recv(csock,ans,25,0);
   sleep(1);
   ll cip=atoll(ans);
   
   ll msg=mulmod(cip,d,n);
   printf("Message is %lld\n",cip);
   close(csock);
   return 0;
   }
