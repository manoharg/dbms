import java.io.*;
import java.net.*;
import java.math.BigInteger;
import java.nio.charset.Charset;

public class rabintestclient {
    public static void main(String[] args) throws UnsupportedEncodingException,IOException {
        
	    
	    Socket clientSocket = new Socket("127.0.0.1",5000);
	    OutputStream os=clientSocket.getOutputStream();
	    BufferedReader is=new BufferedReader(new InputStreamReader(
                            clientSocket.getInputStream()));
           
           
            String s = "Hello world!";
            BigInteger m = new BigInteger(s.getBytes(Charset.forName("ascii")));
            BigInteger N = new BigInteger(is.readLine());
            System.out.println("Public Key Received from server: "+N);
            BigInteger c = rabin.encrypt(m, N);
            System.out.println("Encrypted String is: "+c);
            os.write(c.toString().getBytes());
            os.close();
            is.close();
            clientSocket.close();
    }
}
