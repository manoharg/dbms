#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#define ll long long int
ll summod(ll a,ll b,ll m){
	ll res=0;
	while(b>0){
	if(b%2)
	res=(res+a)%m;
	a=(a*2)%m;
	b>>=1;
	}
	return res;
}
ll mulmod(ll a,ll b,ll m){
	ll res=1;
	a=a%m;
	while(b>0){
	if(b%2)
	res=(summod(res,a,m))%m;
	
	a=(summod(a,a,m))%m;
	b>>=1;
	}
	return res;
}
int main(){
  
  ll ssock;
  ssock=socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
  struct sockaddr_in se;
  
  se.sin_family=PF_INET;
  se.sin_port=htons(3000);
  se.sin_addr.s_addr=inet_addr("127.0.0.1");
  
  ll s1=bind(ssock,(struct sockaddr *)&se,sizeof(se));
  s1=listen(ssock,5);
  
  ll p=sizeof(se);
  s1=accept(ssock,(struct sockaddr *)&se,&p);
  
  char nval[25],eval[25],rval[25];
  
  recv(s1,nval,25,0);
   sleep(1);
  recv(s1,eval,15,0);
   sleep(1);
  ll e=atoll(eval);
  ll n=atoll(nval);
  
  printf("(n,e) received is (%lld,%lld)\n",n,e);
  
  ll msg;
  printf("Enter msg:");
  scanf("%lld",&msg);
  
  ll cip=mulmod(msg,e,n);
  printf("Cipher text is %lld\n",cip);
  
  sprintf(nval,"%lld",cip);
  sprintf(rval,"%lld",msg);
  send(s1,nval,25,0);
   sleep(1);
  //send(s1,rval,25,0);
   //sleep(1);
  close(ssock);
  close(s1);
  return 0;
  }
