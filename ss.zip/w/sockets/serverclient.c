#include<stdio.h>
#include<sys/socket.h>
#include<string.h>
#include<netinet/in.h>
#include<sys/types.h>
#define ll long long int
ll isPrime[1000005];
ll a[100005];
ll k=0;
void init(){
 ll i,j;
 for(i=2;i*i<=1000005;i++){
 if(isPrime[i]==0){
 for(j=i*i;j<=1000005;j+=i){
 isPrime[i]=1;
 }
 }
 }
 
 for(i=2;i<=10005;i++){
  if(isPrime[i]==0)
  a[k++]=i;
  }
 }
ll summod(ll a,ll b,ll m){
	ll res=0;
	while(b>0){
	if(b%2)
	res=(res+a)%m;
	a=(a*2)%m;
	b>>=1;
	}
	return res;
}
ll mulmod(ll a,ll b,ll m){

for(ll i=0;i<b;i++)
{
a=(a*b)%m;
}
return a;

}
/*
ll mulmod(ll a,ll b,ll m){
	ll res=1;
	a=a%m;
	while(b>0){
	if(b%2)
	res=(summod(res,a,m))%m;
	
	a=(summod(a,a,m))%m;
	b>>=1;
	}
	return res%m;
	}
*/

ll gcd(ll a,ll b){
 if(b==0)
 return a;
 return gcd(b,a%b);
 }
 
int main(){
   init();
   srand(time(NULL));
   ll p=a[rand()%(k)];
   ll q=a[rand()%(k)];
  
   ll n=p*q;
   
   ll phi=(p-1)*(q-1);
   
   ll e=2;
   
   while(gcd(e,phi)!=1)
   e++;
   
   
   ll d=1;
   while(((e*d)%phi)!=1)
   d++;
   
   printf("%lld %lld %lld %lld\n",n,e,d,(e*d)%phi);
   
   int csock;
   struct sockaddr_in se,se1;
   csock = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
   //Server
   int ssock;
   ssock=socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
   
   se.sin_family=PF_INET;
   se.sin_port=htons(3000);
   se.sin_addr.s_addr=inet_addr("127.0.0.1");
   
   se1.sin_family=PF_INET;
   se1.sin_port=htons(4000);
   se1.sin_addr.s_addr=inet_addr("127.0.0.1");
   
   int acpt=connect(csock,(struct sockaddr *)&se,sizeof(se));
   
   //Server
   ll s1=bind(ssock,(struct sockaddr *)&se1,sizeof(se1));
   s1=listen(ssock,5);
   ll p1=sizeof(se1);
   s1=accept(ssock,(struct sockaddr *)&se1,&p1);
   
   char nval[25],ans[25],rval[25],ans1[25];
   recv(s1,rval,25,0);
   sleep(1);
     ll re=atoll(rval);
   recv(s1,nval,25,0);
    sleep(1);
 
   ll rn=atoll(nval);
   printf("received %lld,%lld from client\n",re,rn);
   
   
   sprintf(rval,"%lld",n);
   sprintf(nval,"%lld",e);
   send(csock,rval,25,0);
    sleep(1);
   send(csock,nval,25,0);
    sleep(1);
   
   recv(csock,ans,25,0);
    sleep(1);
 //  recv(csock,ans1,25,0);
   // sleep(1);
   ll cip=atoll(ans);
   
   printf("Cipher text is %lld\n",cip);
   
   //Decrypting the message
   ll msg=mulmod(cip,d,n);
  // msg=atoll(ans1);
   printf("Message is %lld\n",msg);
   msg=132;
   ll msg1=mulmod(msg,re,rn);
   sprintf(ans,"%lld",msg);
   send(s1,ans,25,0);
    sleep(1);
   
   close(csock);
   close(ssock);
   close(s1);
   return 0;
   }
